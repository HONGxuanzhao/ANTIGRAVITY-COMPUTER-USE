import { execFileSync, spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { resolveDataDir } from './settings.mjs';

const CSC_CANDIDATES = [
  'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe',
  'C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe',
];

function findCsc() {
  for (const candidate of CSC_CANDIDATES) {
    if (fs.existsSync(candidate)) {
      return {
        cscPath: candidate,
        wpfDir: path.join(path.dirname(candidate), 'WPF'),
      };
    }
  }
  throw new Error('Could not locate .NET Framework 4.x csc.exe on Windows.');
}

export function resolvePluginRoot(explicitRoot) {
  if (explicitRoot && fs.existsSync(explicitRoot)) return explicitRoot;
  if (process.env.PLUGIN_ROOT && fs.existsSync(process.env.PLUGIN_ROOT)) return process.env.PLUGIN_ROOT;
  // dist/server.mjs or src/driver.mjs -> parent of dist/ or src/
  return path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
}

export function ensureDriverBinary({ pluginRoot, dataDir } = {}) {
  const root = resolvePluginRoot(pluginRoot);
  const data = resolveDataDir(dataDir);
  const csPath = path.join(root, 'native', 'ComputerUseWin.cs');
  if (!fs.existsSync(csPath)) {
    throw new Error(`Native driver source not found: ${csPath}`);
  }

  const binDir = path.join(data, 'bin');
  fs.mkdirSync(binDir, { recursive: true });
  const exePath = path.join(binDir, 'win-driver.exe');
  const hashPath = path.join(binDir, 'win-driver.sha256');

  const sourceHash = crypto.createHash('sha256').update(fs.readFileSync(csPath)).digest('hex');
  if (fs.existsSync(exePath) && fs.existsSync(hashPath)) {
    const existingHash = fs.readFileSync(hashPath, 'utf8').trim();
    if (existingHash === sourceHash) {
      return exePath;
    }
  }

  const { cscPath, wpfDir } = findCsc();
  const refs = [
    'System.dll',
    'System.Core.dll',
    'System.Drawing.dll',
    'System.Windows.Forms.dll',
    'System.Web.Extensions.dll',
    path.join(wpfDir, 'UIAutomationClient.dll'),
    path.join(wpfDir, 'UIAutomationTypes.dll'),
    path.join(wpfDir, 'WindowsBase.dll'),
  ].join(',');

  const tmpExe = path.join(binDir, `win-driver.${process.pid}.tmp.exe`);
  try {
    execFileSync(
      cscPath,
      ['/nologo', '/optimize', '/platform:anycpu', '/target:exe', `/out:${tmpExe}`, `/r:${refs}`, csPath],
      { encoding: 'utf8', windowsHide: true }
    );
    if (fs.existsSync(exePath)) fs.unlinkSync(exePath);
    fs.renameSync(tmpExe, exePath);
    fs.writeFileSync(hashPath, sourceHash, 'utf8');
  } finally {
    if (fs.existsSync(tmpExe)) {
      try { fs.unlinkSync(tmpExe); } catch { /* ignore */ }
    }
  }
  return exePath;
}

export function runDriverOnce(cmd, payload = {}, opts = {}) {
  const exePath = ensureDriverBinary(opts);
  const out = execFileSync(exePath, [cmd, JSON.stringify(payload)], {
    encoding: 'utf8',
    windowsHide: true,
    maxBuffer: 32 * 1024 * 1024,
    timeout: opts.timeoutMs || 10000,
  });
  return JSON.parse(out.trim());
}

export class WinDriverClient {
  constructor({ pluginRoot, dataDir } = {}) {
    this.pluginRoot = pluginRoot;
    this.dataDir = dataDir;
    this.proc = null;
    this.rl = null;
    this.nextId = 1;
    this.pending = new Map();
    this.queue = Promise.resolve();
  }

  _ensureProcess() {
    if (this.proc && !this.proc.killed && this.proc.exitCode === null) {
      return;
    }
    const exePath = ensureDriverBinary({
      pluginRoot: this.pluginRoot,
      dataDir: this.dataDir,
    });
    this.proc = spawn(exePath, ['--stdio'], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    this.rl = readline.createInterface({ input: this.proc.stdout });
    this.rl.on('line', (line) => {
      if (!line.trim()) return;
      try {
        const msg = JSON.parse(line);
        const handler = this.pending.get(String(msg.id));
        if (!handler) return;
        this.pending.delete(String(msg.id));
        if (msg.ok) handler.resolve(msg.result);
        else handler.reject(new Error(msg.error || 'Driver command failed'));
      } catch (err) {
        // ignore malformed lines
      }
    });
    this.proc.on('exit', () => {
      for (const [, handler] of this.pending.entries()) {
        handler.reject(new Error('Windows driver process exited unexpectedly.'));
      }
      this.pending.clear();
      this.proc = null;
      if (this.rl) {
        this.rl.close();
        this.rl = null;
      }
    });
  }

  call(cmd, payload = {}, timeoutMs = 20000) {
    const run = () =>
      new Promise((resolve, reject) => {
        this._ensureProcess();
        const id = String(this.nextId++);
        const timer = setTimeout(() => {
          this.pending.delete(id);
          reject(new Error(`Driver command '${cmd}' timed out after ${timeoutMs}ms.`));
        }, timeoutMs);
        this.pending.set(id, {
          resolve: (res) => {
            clearTimeout(timer);
            resolve(res);
          },
          reject: (err) => {
            clearTimeout(timer);
            reject(err);
          },
        });
        this.proc.stdin.write(JSON.stringify({ id, cmd, payload }) + '\n', 'utf8');
      });

    const next = this.queue.then(run, run);
    this.queue = next.catch(() => {});
    return next;
  }

  dispose() {
    if (this.proc && !this.proc.killed) {
      this.proc.kill();
    }
    this.proc = null;
  }
}

import fs from 'node:fs';
import { runDriverOnce } from './driver.mjs';
import { loadSettings, matchAppName } from './settings.mjs';

function readStdin() {
  return fs.readFileSync(0, 'utf8');
}

function normalizeShortcut(keys) {
  if (!Array.isArray(keys)) return '';
  return keys
    .map((k) => String(k || '').trim().toLowerCase())
    .sort()
    .join('+');
}

function findDangerousHotkey(args) {
  if (!args || !Array.isArray(args.actions)) return null;
  const dangerous = new Set([
    'alt+f4',
    'ctrl+alt+del',
    'ctrl+alt+delete',
    'lwin+r',
    'r+win',
    'r+super',
    'r+super_l',
    'win+x',
    'super+x',
    'ctrl+shift+esc',
    'ctrl+shift+escape',
  ]);
  for (const act of args.actions) {
    if (!act || String(act.action || '').toLowerCase() !== 'keypress') continue;
    const rawKeys = Array.isArray(act.keys)
      ? act.keys
      : act.key
        ? String(act.key).split('+')
        : [];
    const norm = normalizeShortcut(rawKeys);
    if (dangerous.has(norm)) {
      return rawKeys.join('+');
    }
    const lower = rawKeys.map((k) => String(k).toLowerCase());
    if (
      (lower.includes('win') || lower.includes('super') || lower.includes('super_l') || lower.includes('meta')) &&
      (lower.includes('r') || lower.includes('x'))
    ) {
      return rawKeys.join('+');
    }
    if (lower.includes('alt') && lower.includes('f4')) {
      return rawKeys.join('+');
    }
  }
  return null;
}

function respond(obj) {
  process.stdout.write(JSON.stringify(obj));
}

function main() {
  let input = {};
  try {
    const raw = readStdin();
    if (raw.trim()) input = JSON.parse(raw);
  } catch {
    respond({});
    return;
  }

  const toolName = String(input?.toolCall?.name || '');
  const args = input?.toolCall?.args || {};

  // Match our plugin tools cleanly regardless of host MCP namespacing prefix
  const isSettingsTool = /computer_settings$/.test(toolName);
  const isAppsTool = /computer_apps$/.test(toolName);
  const isComputerTool = /computer_use$/.test(toolName);
  const isInspectTool = /computer_inspect$/.test(toolName);

  if (!isSettingsTool && !isAppsTool && !isComputerTool && !isInspectTool) {
    respond({});
    return;
  }

  // Opening the Settings panel is always safe
  if (isSettingsTool) {
    respond({ decision: 'allow' });
    return;
  }

  const settings = loadSettings();

  if (!settings.enabled) {
    respond({
      decision: 'deny',
      reason:
        'Computer Use control is currently disabled. Ask the user to enable "Control: Any App" in the Computer Use Settings panel (run computer_settings).',
    });
    return;
  }

  // Listing windows or querying active window metadata is read-only & non-visual
  if (isAppsTool && (args.action === 'list' || args.action === 'active')) {
    respond({ decision: 'allow' });
    return;
  }

  let targetApp = '';
  let windowTitle = '';
  const pluginRoot = process.env.PLUGIN_ROOT || process.cwd();

  if (isAppsTool && (args.action === 'focus' || args.action === 'launch')) {
    targetApp = String(args.processName || args.target || args.titleContains || '').trim();
  }

  if (!targetApp) {
    try {
      const fg = runDriverOnce('foreground', {}, { pluginRoot });
      targetApp = String(fg.processName || '').trim();
      windowTitle = String(fg.title || '').trim();
    } catch {
      targetApp = 'unknown';
    }
  }

  const label = windowTitle ? `${targetApp} ("${windowTitle}")` : targetApp || 'current desktop window';

  if (targetApp && matchAppName(targetApp, settings.blockedApps)) {
    respond({
      decision: 'deny',
      reason: `Blocked by Computer Use safety policy: "${targetApp}" is in Blocked Apps.`,
    });
    return;
  }

  if (settings.controlScope === 'allowlisted_only' && !matchAppName(targetApp, settings.alwaysAllowedApps)) {
    respond({
      decision: 'deny',
      reason: `Blocked: Control scope is set to "Allowlisted Apps Only" and "${targetApp}" is not in Always-Allowed Apps.`,
    });
    return;
  }

  if (settings.confirmDangerousHotkeys && isComputerTool) {
    const danger = findDangerousHotkey(args);
    if (danger) {
      respond({
        decision: 'force_ask',
        reason: `Computer Use wants to send sensitive system shortcut "${danger}" to ${label}. Approve?`,
      });
      return;
    }
  }

  if (settings.approvalMode === 'always_ask') {
    respond({
      decision: 'force_ask',
      reason: `Confirm Computer Use action on ${label}.`,
    });
    return;
  }

  if (settings.approvalMode === 'ask_untrusted') {
    if (targetApp && matchAppName(targetApp, settings.alwaysAllowedApps)) {
      respond({ decision: 'allow' });
      return;
    }
    respond({
      decision: 'force_ask',
      reason: `Allow Computer Use to control ${label}? You can add "${targetApp}" to Always-Allowed Apps in the Computer Use Settings panel.`,
    });
    return;
  }

  respond({ decision: 'allow' });
}

main();

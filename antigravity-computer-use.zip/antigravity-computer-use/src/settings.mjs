import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const DEFAULT_SETTINGS = {
  enabled: true,
  controlScope: 'any_app',
  approvalMode: 'ask_untrusted', // 'ask_untrusted' | 'always_ask' | 'always_allow'
  alwaysAllowedApps: [
    'notepad.exe',
    'calc.exe',
    'CalculatorApp.exe',
    'ApplicationFrameHost.exe',
    'mspaint.exe',
  ],
  blockedApps: [
    '1Password.exe',
    'Bitwarden.exe',
    'KeePass.exe',
    'KeePassXC.exe',
    'Taskmgr.exe',
    'Consent.exe',
    'CredentialUIBroker.exe',
    'cmdkey.exe',
    'regedit.exe',
    'mmc.exe',
  ],
  coordSpace: 'normalized_1000', // 'normalized_1000' | 'image_pixels' | 'screen_pixels'
  screenScope: 'active_monitor', // 'active_monitor' | 'primary' | 'virtual'
  maxImageWidth: 1440,
  showSoM: 'auto', // 'auto' | 'always' | 'off'
  showCursor: true,
  visualHud: true,
  cursorMorph: true,
  preActionDelayMs: 1500,
  postActionHoldMs: 4000,
  failsafe: true,
  postActionDelayMs: 250,
  confirmDangerousHotkeys: true,
};

export function resolveDataDir(explicitDir) {
  const dir =
    explicitDir ||
    process.env.PLUGIN_DATA ||
    process.env.ANTIGRAVITY_CU_DATA ||
    path.join(os.homedir(), '.gemini', 'config', 'computer-use-data');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function getSettingsPath(dataDir) {
  return path.join(resolveDataDir(dataDir), 'settings.json');
}

export function getAuditLogPath(dataDir) {
  return path.join(resolveDataDir(dataDir), 'audit.json');
}

export function getScreenshotsDir(dataDir) {
  const dir = path.join(resolveDataDir(dataDir), 'screenshots');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function normalizeAppList(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const result = [];
  for (const raw of list) {
    const item = String(raw || '').trim();
    if (!item) continue;
    const key = item.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(item);
  }
  return result;
}

export function normalizeSettings(input) {
  const merged = {
    ...DEFAULT_SETTINGS,
    ...(input && typeof input === 'object' ? input : {}),
  };
  merged.enabled = Boolean(merged.enabled);
  merged.controlScope = merged.controlScope === 'allowlisted_only' ? 'allowlisted_only' : 'any_app';
  if (!['ask_untrusted', 'always_ask', 'always_allow'].includes(merged.approvalMode)) {
    merged.approvalMode = DEFAULT_SETTINGS.approvalMode;
  }
  if (!['normalized_1000', 'image_pixels', 'screen_pixels'].includes(merged.coordSpace)) {
    merged.coordSpace = DEFAULT_SETTINGS.coordSpace;
  }
  if (!['active_monitor', 'primary', 'virtual'].includes(merged.screenScope)) {
    merged.screenScope = DEFAULT_SETTINGS.screenScope;
  }
  if (!['auto', 'always', 'off'].includes(merged.showSoM)) {
    merged.showSoM = DEFAULT_SETTINGS.showSoM;
  }
  merged.maxImageWidth = Math.max(640, Math.min(3840, Number(merged.maxImageWidth) || 1440));
  merged.preActionDelayMs = Math.max(0, Math.min(5000, Number(merged.preActionDelayMs ?? 1500)));
  merged.postActionHoldMs = Math.max(500, Math.min(15000, Number(merged.postActionHoldMs ?? 4000)));
  merged.postActionDelayMs = Math.max(0, Math.min(3000, Number(merged.postActionDelayMs ?? 250)));
  merged.showCursor = Boolean(merged.showCursor);
  merged.visualHud = Boolean(merged.visualHud);
  merged.cursorMorph = Boolean(merged.cursorMorph);
  merged.failsafe = Boolean(merged.failsafe);
  merged.confirmDangerousHotkeys = Boolean(merged.confirmDangerousHotkeys);
  merged.alwaysAllowedApps = normalizeAppList(merged.alwaysAllowedApps);
  merged.blockedApps = normalizeAppList(merged.blockedApps);
  return merged;
}

export function loadSettings(dataDir) {
  const filePath = getSettingsPath(dataDir);
  if (!fs.existsSync(filePath)) {
    const initial = normalizeSettings(DEFAULT_SETTINGS);
    saveSettings(initial, dataDir);
    return initial;
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    return normalizeSettings(JSON.parse(raw));
  } catch {
    return normalizeSettings(DEFAULT_SETTINGS);
  }
}

export function saveSettings(nextSettings, dataDir) {
  const filePath = getSettingsPath(dataDir);
  const normalized = normalizeSettings(nextSettings);
  const tmpPath = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(normalized, null, 2), 'utf8');
  fs.renameSync(tmpPath, filePath);
  return normalized;
}

export function matchAppName(processName, list) {
  if (!processName || !Array.isArray(list)) return false;
  const target = String(processName).trim().toLowerCase();
  const baseTarget = target.replace(/\.exe$/i, '');
  return list.some((entry) => {
    const candidate = String(entry).trim().toLowerCase();
    const baseCandidate = candidate.replace(/\.exe$/i, '');
    return candidate === target || baseCandidate === baseTarget;
  });
}

export function appendAuditEntry(entry, dataDir) {
  const auditPath = getAuditLogPath(dataDir);
  let entries = [];
  try {
    if (fs.existsSync(auditPath)) {
      const parsed = JSON.parse(fs.readFileSync(auditPath, 'utf8'));
      if (Array.isArray(parsed)) entries = parsed;
    }
  } catch {
    entries = [];
  }
  entries.unshift({
    timestamp: new Date().toISOString(),
    ...entry,
  });
  if (entries.length > 40) {
    entries = entries.slice(0, 40);
  }
  const tmpPath = `${auditPath}.${process.pid}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(entries, null, 2), 'utf8');
  fs.renameSync(tmpPath, auditPath);
  return entries;
}

export function loadAuditLog(dataDir) {
  const auditPath = getAuditLogPath(dataDir);
  try {
    if (fs.existsSync(auditPath)) {
      const parsed = JSON.parse(fs.readFileSync(auditPath, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

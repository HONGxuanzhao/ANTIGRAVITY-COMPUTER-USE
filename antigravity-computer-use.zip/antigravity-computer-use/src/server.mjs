import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  RESOURCE_MIME_TYPE,
  registerAppResource,
  registerAppTool,
} from '@modelcontextprotocol/ext-apps/server';
import fs from 'node:fs';
import path from 'node:path';
import { z } from 'zod/v4';
import { WinDriverClient, resolvePluginRoot } from './driver.mjs';
import {
  appendAuditEntry,
  getAuditLogPath,
  getScreenshotsDir,
  loadAuditLog,
  loadSettings,
  matchAppName,
  resolveDataDir,
  saveSettings,
} from './settings.mjs';

const APP_URI = 'ui://computer-use/settings.html';

function parseCliArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--plugin-root' && argv[i + 1]) {
      out.pluginRoot = argv[++i];
    } else if (argv[i] === '--data-dir' && argv[i + 1]) {
      out.dataDir = argv[++i];
    }
  }
  return out;
}

const cli = parseCliArgs(process.argv.slice(2));
const pluginRoot = resolvePluginRoot(cli.pluginRoot);
const dataDir = resolveDataDir(cli.dataDir);
const driver = new WinDriverClient({ pluginRoot, dataDir });

let lastElements = [];
let lastCaptureMeta = { w: 0, h: 0 };

function formatElementsSummary(elements) {
  if (!Array.isArray(elements) || elements.length === 0) return 'None detected';
  return elements
    .slice(0, 60)
    .map((el) => {
      const name = el.name ? ` "${el.name.replace(/\s+/g, ' ').slice(0, 60)}"` : '';
      const cx = el.centerNorm?.x ?? 0;
      const cy = el.centerNorm?.y ?? 0;
      return `[${el.id}] ${el.type}${name} @ (${cx}, ${cy})`;
    })
    .join('\n');
}

function resolveSoMFlag(explicitFlag, settings) {
  if (typeof explicitFlag === 'boolean') return explicitFlag;
  return settings.showSoM === 'always';
}

function expandActionElements(actions) {
  return actions.map((act) => {
    const copy = { ...act };
    if (copy.element_id !== undefined && copy.element_id !== null) {
      const targetId = Number(copy.element_id);
      const found = lastElements.find((el) => Number(el.id) === targetId);
      if (!found) {
        throw new Error(
          `Unknown element_id ${targetId}. Run computer_inspect or computer_use with showSoM=true first.`
        );
      }
      copy.screenX = found.centerScreen.x;
      copy.screenY = found.centerScreen.y;
    }
    return copy;
  });
}

async function assertDefenseInDepth(targetAppHint) {
  const settings = loadSettings(dataDir);
  if (!settings.enabled) {
    throw new Error(
      'Computer Use control is disabled in Settings. Open computer_settings to enable Any App Control.'
    );
  }
  let fg = null;
  try {
    fg = await driver.call('foreground');
  } catch {
    fg = { processName: '', title: '' };
  }
  const proc = String(targetAppHint || fg.processName || '').trim();
  if (proc && matchAppName(proc, settings.blockedApps)) {
    throw new Error(`Blocked by safety policy: "${proc}" is in Blocked Apps.`);
  }
  if (
    settings.controlScope === 'allowlisted_only' &&
    proc &&
    !matchAppName(proc, settings.alwaysAllowedApps)
  ) {
    throw new Error(
      `Blocked: Control Scope is "Always-Allowed Apps Only" and "${proc}" is not allowlisted.`
    );
  }
  return { settings, fg };
}

function buildCaptureResponse(snap, settings, extraHeader = '') {
  if (Array.isArray(snap.elements) && snap.elements.length > 0) {
    lastElements = snap.elements;
  }
  if (snap.imageSize) {
    lastCaptureMeta = snap.imageSize;
  }

  const lines = [];
  if (extraHeader) lines.push(extraHeader);
  lines.push(`Foreground App: ${snap.processName || '(none)'} | Title: ${snap.title || '(none)'}`);
  lines.push(
    `Capture Bounds: ${snap.captureBounds?.w || 0}x${snap.captureBounds?.h || 0} @ (${snap.captureBounds?.x || 0}, ${snap.captureBounds?.y || 0}) | Coord Space: ${settings.coordSpace}`
  );
  lines.push(
    `Image Size: ${snap.imageSize?.w || 0}x${snap.imageSize?.h || 0} | Cursor: (${snap.cursor?.x || 0}, ${snap.cursor?.y || 0})`
  );
  if (snap.imagePath) {
    lines.push(`Saved Screenshot: ${snap.imagePath}`);
  }
  if (Array.isArray(snap.elements) && snap.elements.length > 0) {
    lines.push('UI Elements (Set-of-Mark IDs & normalized 0..1000 centers):');
    lines.push(formatElementsSummary(snap.elements));
  }

  const content = [];
  if (snap.base64) {
    content.push({
      type: 'image',
      data: snap.base64,
      mimeType: snap.mimeType || 'image/png',
    });
  }
  content.push({
    type: 'text',
    text: lines.join('\n'),
  });
  return { content };
}

const server = new McpServer({
  name: 'computer-use',
  version: '0.1.0',
});

registerAppResource(
  server,
  'Computer Use Settings',
  APP_URI,
  {
    description: 'Codex-style Computer Use control, Always-Allowed apps, safety, and preview UI',
    _meta: { ui: { prefersBorder: false } },
  },
  async () => {
    const htmlPath = path.join(pluginRoot, 'dist', 'app.html');
    const text = fs.readFileSync(htmlPath, 'utf8');
    return {
      contents: [
        {
          uri: APP_URI,
          mimeType: RESOURCE_MIME_TYPE,
          text,
          _meta: { ui: { prefersBorder: false } },
        },
      ],
    };
  }
);

registerAppTool(
  server,
  'computer_settings',
  {
    title: 'Computer Use Settings',
    description:
      'Open the Codex-style Computer Use settings panel to toggle Control, manage Always-allowed apps and Blocked apps, configure coordinate mode, and preview desktop screenshots.',
    inputSchema: z.object({}),
    _meta: {
      ui: { resourceUri: APP_URI },
      'com.google.antigravity/ui': {
        entrypoints: [
          { type: 'aux_pane', title: 'Computer Use' },
          { type: 'global', title: 'Computer Use' },
        ],
      },
    },
  },
  async () => {
    const settings = loadSettings(dataDir);
    const auditLog = loadAuditLog(dataDir);
    let runningWindows = [];
    try {
      runningWindows = await driver.call('list_windows');
    } catch {
      runningWindows = [];
    }
    return {
      content: [
        {
          type: 'text',
          text: `Computer Use Settings: enabled=${settings.enabled}, scope=${settings.controlScope}, approval=${settings.approvalMode}, alwaysAllowedApps=[${settings.alwaysAllowedApps.join(', ')}]`,
        },
      ],
      structuredContent: {
        settings,
        auditLog,
        runningWindows,
      },
    };
  }
);

// App-only tools (callable strictly by the MCP App UI, hidden from the model)
registerAppTool(
  server,
  'app_get_state',
  {
    description: 'Load current Computer Use settings, running windows, and recent audit log',
    inputSchema: z.object({}),
    _meta: { ui: { resourceUri: APP_URI, visibility: ['app'] } },
  },
  async () => {
    const settings = loadSettings(dataDir);
    const auditLog = loadAuditLog(dataDir);
    let runningWindows = [];
    try {
      runningWindows = await driver.call('list_windows');
    } catch {
      runningWindows = [];
    }
    return {
      content: [{ type: 'text', text: 'ok' }],
      structuredContent: { settings, auditLog, runningWindows },
    };
  }
);

registerAppTool(
  server,
  'app_save_settings',
  {
    description: 'Persist updated Computer Use settings from UI',
    inputSchema: z.object({ settings: z.record(z.string(), z.any()) }),
    _meta: { ui: { resourceUri: APP_URI, visibility: ['app'] } },
  },
  async ({ settings: next }) => {
    const saved = saveSettings(next, dataDir);
    return {
      content: [{ type: 'text', text: 'saved' }],
      structuredContent: { settings: saved },
    };
  }
);

registerAppTool(
  server,
  'app_list_running',
  {
    description: 'List currently visible desktop windows for quick allowlist selection',
    inputSchema: z.object({}),
    _meta: { ui: { resourceUri: APP_URI, visibility: ['app'] } },
  },
  async () => {
    const runningWindows = await driver.call('list_windows');
    return {
      content: [{ type: 'text', text: `Found ${runningWindows.length} windows` }],
      structuredContent: { runningWindows },
    };
  }
);

registerAppTool(
  server,
  'app_capture_preview',
  {
    description: 'Capture live desktop preview screenshot for the settings panel',
    inputSchema: z.object({}),
    _meta: { ui: { resourceUri: APP_URI, visibility: ['app'] } },
  },
  async () => {
    const settings = loadSettings(dataDir);
    const outputPath = path.join(getScreenshotsDir(dataDir), 'preview.png');
    const snap = await driver.call('capture', {
      screenScope: settings.screenScope,
      maxImageWidth: Math.min(1280, settings.maxImageWidth),
      showSoM: settings.showSoM === 'always',
      showCursor: settings.showCursor,
      outputPath,
    });
    const mime = snap.mimeType || 'image/png';
    return {
      content: [{ type: 'text', text: 'captured' }],
      structuredContent: {
        previewDataUrl: snap.base64 ? `data:${mime};base64,${snap.base64}` : '',
        previewCaption: `${snap.processName || 'Desktop'} — ${snap.imageSize?.w || 0}x${snap.imageSize?.h || 0}`,
      },
    };
  }
);

registerAppTool(
  server,
  'app_clear_audit',
  {
    description: 'Clear recent Computer Use audit entries',
    inputSchema: z.object({}),
    _meta: { ui: { resourceUri: APP_URI, visibility: ['app'] } },
  },
  async () => {
    const auditPath = getAuditLogPath(dataDir);
    fs.writeFileSync(auditPath, '[]', 'utf8');
    return {
      content: [{ type: 'text', text: 'cleared' }],
      structuredContent: { auditLog: [] },
    };
  }
);

server.registerTool(
  'computer_apps',
  {
    title: 'Desktop Apps & Windows',
    description:
      'List open Windows applications, check the active foreground app, bring a target app window to the foreground (required on Windows Active Desktop), or launch an application.',
    inputSchema: z.object({
      action: z.enum(['list', 'active', 'focus', 'launch']),
      processName: z.string().optional().describe('Process name filter, e.g. notepad.exe'),
      titleContains: z.string().optional().describe('Case-insensitive substring of window title'),
      hwnd: z.string().optional().describe('Exact window handle string from list'),
      target: z.string().optional().describe('Executable or path to launch (for launch action)'),
      args: z.string().optional().describe('Optional CLI arguments for launch'),
    }),
  },
  async ({ action, processName, titleContains, hwnd, target, args }) => {
    const settings = loadSettings(dataDir);
    if (!settings.enabled) {
      throw new Error('Computer Use is disabled. Open computer_settings to enable it.');
    }

    if (action === 'list') {
      const windows = await driver.call('list_windows');
      const annotated = windows.map((w) => ({
        ...w,
        allowed: matchAppName(w.processName, settings.alwaysAllowedApps),
        blocked: matchAppName(w.processName, settings.blockedApps),
      }));
      return {
        content: [{ type: 'text', text: JSON.stringify(annotated, null, 2) }],
      };
    }

    if (action === 'active') {
      const fg = await driver.call('foreground');
      return {
        content: [{ type: 'text', text: JSON.stringify(fg, null, 2) }],
      };
    }

    if (action === 'focus') {
      await assertDefenseInDepth(processName || '');
      const fg = await driver.call('focus_window', {
        hwnd,
        processName,
        titleContains,
        visualHud: settings.visualHud,
        postActionHoldMs: settings.postActionHoldMs,
        screenScope: settings.screenScope,
      });
      if (matchAppName(fg.processName, settings.blockedApps)) {
        throw new Error(`Blocked: focused window "${fg.processName}" is in Blocked Apps.`);
      }
      appendAuditEntry(
        { tool: 'computer_apps', summary: `focus ${fg.processName || titleContains}`, app: fg.processName },
        dataDir
      );
      return {
        content: [{ type: 'text', text: `Focused: ${JSON.stringify(fg)}` }],
      };
    }

    await assertDefenseInDepth(target || '');
    const fg = await driver.call('launch_app', {
      target,
      args,
      visualHud: settings.visualHud,
      postActionHoldMs: settings.postActionHoldMs,
      screenScope: settings.screenScope,
    });
    appendAuditEntry(
      { tool: 'computer_apps', summary: `launch ${target}`, app: fg.processName || target },
      dataDir
    );
    return {
      content: [{ type: 'text', text: `Launched "${target}". Foreground: ${JSON.stringify(fg)}` }],
    };
  }
);

server.registerTool(
  'computer_inspect',
  {
    title: 'Inspect Desktop UI (UIA + Set-of-Mark)',
    description:
      'Capture the active Windows desktop screen with numbered Set-of-Mark (SoM) UI Automation tags on interactive controls so you can click accurately by element_id or normalized 0-1000 coordinates.',
    inputSchema: z.object({
      showGrid: z.boolean().optional().describe('Overlay a 0-1000 coordinate grid (useful for custom canvases)'),
      maxElements: z.number().int().min(10).max(150).optional(),
    }),
  },
  async ({ showGrid, maxElements }) => {
    const { settings, fg } = await assertDefenseInDepth();
    const outputPath = path.join(getScreenshotsDir(dataDir), 'latest.png');
    const snap = await driver.call('capture', {
      screenScope: settings.screenScope,
      maxImageWidth: settings.maxImageWidth,
      showSoM: settings.showSoM !== 'off',
      showCursor: settings.showCursor,
      visualHud: settings.visualHud,
      cursorMorph: settings.cursorMorph,
      postActionHoldMs: settings.postActionHoldMs,
      showGrid: Boolean(showGrid),
      maxElements: maxElements || 80,
      outputPath,
    });
    appendAuditEntry(
      {
        tool: 'computer_inspect',
        summary: `inspect (${snap.elements?.length || 0} UIA elements)`,
        app: fg.processName || snap.processName,
      },
      dataDir
    );
    return buildCaptureResponse(snap, settings);
  }
);

const pointSchema = z.object({
  x: z.number(),
  y: z.number(),
});

const actionSchema = z.object({
  action: z.enum([
    'screenshot',
    'move',
    'click',
    'double_click',
    'triple_click',
    'drag',
    'scroll',
    'type',
    'keypress',
    'wait',
  ]),
  x: z.number().optional().describe('Target X coordinate (default normalized 0..1000)'),
  y: z.number().optional().describe('Target Y coordinate (default normalized 0..1000)'),
  element_id: z
    .number()
    .int()
    .optional()
    .describe('Optional Set-of-Mark element ID from computer_inspect / prior screenshot'),
  button: z.enum(['left', 'right', 'middle']).optional(),
  keys: z.array(z.string()).optional().describe('Key list for keypress (e.g. ["Ctrl","S"]) or click modifiers'),
  key: z.string().optional().describe('Single key or chord string like "Return" or "Ctrl+C"'),
  text: z.string().optional().describe('Unicode text to type'),
  delayMs: z.number().int().min(0).max(100).optional(),
  scrollX: z.number().int().optional().describe('Horizontal scroll notches (positive=right)'),
  scrollY: z.number().int().optional().describe('Vertical scroll notches (positive=down, negative=up)'),
  fromX: z.number().optional(),
  fromY: z.number().optional(),
  toX: z.number().optional(),
  toY: z.number().optional(),
  path: z.array(pointSchema).optional(),
  ms: z.number().int().min(20).max(10000).optional(),
});

server.registerTool(
  'computer_use',
  {
    title: 'Computer Use (Codex-Style GUI Actions)',
    description:
      'Execute an ordered batch of desktop GUI actions (move, click, double_click, triple_click, drag, scroll, type, keypress, wait, screenshot) on the active Windows desktop and return a fresh post-action screenshot.',
    inputSchema: z.object({
      actions: z.array(actionSchema).min(1).max(20),
      targetApp: z
        .string()
        .optional()
        .describe('Optional target process name (e.g. notepad.exe) to ensure is focused in foreground before executing actions'),
      coordSpace: z.enum(['normalized_1000', 'image_pixels', 'screen_pixels']).optional(),
      showSoM: z.boolean().optional().describe('Overlay UIA element numbers on the returned screenshot'),
      showGrid: z.boolean().optional().describe('Overlay 0-1000 coordinate grid on the returned screenshot'),
    }),
  },
  async ({ actions, targetApp, coordSpace, showSoM, showGrid }) => {
    const { settings, fg } = await assertDefenseInDepth(targetApp || '');
    const resolvedActions = expandActionElements(actions);
    const effectiveCoordSpace = coordSpace || settings.coordSpace;
    const outputPath = path.join(getScreenshotsDir(dataDir), 'latest.png');

    const snap = await driver.call(
      'act',
      {
        actions: resolvedActions,
        targetApp: targetApp || '',
        coordSpace: effectiveCoordSpace,
        screenScope: settings.screenScope,
        maxImageWidth: settings.maxImageWidth,
        imageWidth: lastCaptureMeta.w || 0,
        imageHeight: lastCaptureMeta.h || 0,
        showSoM: resolveSoMFlag(showSoM, settings),
        showCursor: settings.showCursor,
        visualHud: settings.visualHud,
        cursorMorph: settings.cursorMorph,
        showGrid: Boolean(showGrid),
        failsafe: settings.failsafe,
        preActionDelayMs: settings.preActionDelayMs,
        postActionHoldMs: settings.postActionHoldMs,
        postActionDelayMs: settings.postActionDelayMs,
        outputPath,
      },
      30000
    );

    const summary = actions.map((a) => a.action).join(' -> ');
    appendAuditEntry(
      {
        tool: 'computer_use',
        summary,
        app: fg.processName || snap.processName,
      },
      dataDir
    );

    return buildCaptureResponse(
      snap,
      { ...settings, coordSpace: effectiveCoordSpace },
      `Executed ${snap.executedActions || actions.length} action(s): ${summary}`
    );
  }
);

async function main() {
  const transport = new StdioServerTransport();
  transport.onclose = () => {
    driver.dispose();
  };
  process.stdin.on('close', () => {
    driver.dispose();
  });
  process.on('exit', () => {
    driver.dispose();
  });
  await server.connect(transport);
}

process.on('SIGINT', () => {
  driver.dispose();
  process.exit(0);
});
process.on('SIGTERM', () => {
  driver.dispose();
  process.exit(0);
});

main().catch((err) => {
  process.stderr.write(`computer-use server fatal error: ${err?.stack || err}\n`);
  driver.dispose();
  process.exit(1);
});

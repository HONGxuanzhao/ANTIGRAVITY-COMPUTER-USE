param(
  [ValidateSet('Global', 'Workspace')]
  [string]$Scope = 'Global',
  [string]$WorkspacePath = (Get-Location).Path,
  [switch]$PurgeData
)

$ErrorActionPreference = 'Stop'

if ($Scope -eq 'Global') {
  $TargetDir = Join-Path $env:USERPROFILE '.gemini\config\plugins\computer-use'
} else {
  $TargetDir = Join-Path $WorkspacePath '.agents\plugins\computer-use'
}

if (Test-Path $TargetDir) {
  Remove-Item -Recurse -Force $TargetDir
  Write-Host "Removed plugin from: $TargetDir" -ForegroundColor Green
} else {
  Write-Host "Plugin directory not found at: $TargetDir" -ForegroundColor Yellow
}

if ($PurgeData) {
  $DataDir = Join-Path $env:USERPROFILE '.gemini\config\computer-use-data'
  if (Test-Path $DataDir) {
    Remove-Item -Recurse -Force $DataDir
    Write-Host "Purged plugin data directory: $DataDir" -ForegroundColor Yellow
  }
}

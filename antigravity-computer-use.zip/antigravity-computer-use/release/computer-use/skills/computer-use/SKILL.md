---
name: computer-use
description: >-
  Operate Windows desktop GUI applications like Codex Computer Use using
  computer_use, computer_apps, computer_inspect, and computer_settings. Use when
  automating native Windows software, reproducing GUI bugs, or controlling apps
  without CLI/API access.
---

# Windows Computer Use Workflow

Follow this loop to control Windows desktop applications safely and accurately:

## 1. Choose the Right Tool First

- **Web pages / web apps**: Prefer Antigravity's built-in `/browser` subagent.
- **Files / CLI / scripts**: Prefer `run_command`, `read_file`, `edit_file`, and `write_file`.
- **Native Windows GUI apps**: Use `computer_apps`, `computer_inspect`, and `computer_use`.
- **Settings / Allowlist**: Use `computer_settings` to open the Codex-style Computer Use settings panel (`Control: Any App`, `Always-allowed apps`, coordinate mode, and audit trail).

## 2. Focus the Target Application (Active Desktop)

Windows requires the target application to be visible in the foreground before capturing or sending inputs:

1. Call `computer_apps(action="list")` to inspect open windows (`hwnd`, `processName`, `title`, `isForeground`).
2. Call `computer_apps(action="focus", processName="...")` (or `launch`) to bring the target app to the foreground.

## 3. Observe Before Acting (UIA + Set-of-Mark + Screenshot)

- Call `computer_inspect()` or `computer_use(actions=[{"action": "screenshot"}], showSoM=true)` first.
- When `showSoM` is enabled, interactive controls are numbered (`1`, `2`, `3`, ...). Prefer targeting controls by `element_id` (e.g., `{"action": "click", "element_id": 5}`) or normalized `0..1000` coordinates (`{"action": "click", "x": 500, "y": 320}`).
- For custom-drawn canvases (CAD, maps, games) with sparse UIA elements, use `showGrid=true` on screenshot to read `0..1000` grid coordinates accurately.

## 4. Execute Small Verified Batches

- You may batch a short deterministic sequence in one `computer_use` call — e.g. `click` an input box -> `type` text -> `keypress` `["Return"]`.
- When operating a specific window, pass `targetApp` (e.g. `targetApp: "notepad.exe"`) to `computer_use` so the driver verifies and restores foreground focus before acting, preventing accidental clicks on background windows.
- Every `computer_use` call automatically returns a fresh post-action screenshot. Always inspect the returned screenshot before deciding the next step.
- If an app triggers a permission prompt via `PreToolUse`, wait for the user's approval or tell the user they can add the app to **Always-allowed apps** in `computer_settings`.

## 5. Failsafe & Safety

- Moving the cursor to the top-left corner `(0, 0)` triggers an immediate `FAILSAFE_ABORT`.
- Never send credentials or operate blocked security/password apps.
- Never attempt to edit `settings.json` directly via shell commands to bypass user approvals.

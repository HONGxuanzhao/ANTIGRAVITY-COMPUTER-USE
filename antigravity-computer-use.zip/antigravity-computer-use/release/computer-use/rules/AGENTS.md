# Computer Use (Windows) Rules

- Use `computer_use`, `computer_apps`, and `computer_inspect` ONLY for interacting with native Windows desktop applications or GUI workflows that cannot be handled cleanly via terminal commands, file edits, or Antigravity's built-in `/browser` subagent.
- On Windows, target applications must be visible in the foreground Active Desktop (`computer_apps` -> `focus`) before sending mouse or keyboard actions.
- Respect the user's Computer Use safety controls (`Control: Any App`, `Always-allowed apps`, `Blocked apps`, and `PreToolUse` approval prompts). Never edit `settings.json` directly on disk to bypass app permissions; if the user needs to change settings or add an app to `Always-allowed apps`, call `computer_settings` to open the interactive settings panel.
- Read the `computer-use` skill before performing multi-step desktop GUI automation.

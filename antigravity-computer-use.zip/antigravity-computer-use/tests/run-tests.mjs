import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const tmpData = fs.mkdtempSync(path.join(os.tmpdir(), 'agy-cu-test-'));

function checkJsonFiles() {
  const pluginJson = JSON.parse(fs.readFileSync(path.join(root, 'plugin.json'), 'utf8'));
  assert.equal(pluginJson.name, 'computer-use');
  assert.ok(fs.existsSync(path.join(root, pluginJson.logo)));

  const allowedKeys = new Set([
    'name',
    'displayName',
    'description',
    'version',
    'author',
    'homepage',
    'repository',
    'logo',
    'suggestedPrompts',
    'disabled',
  ]);
  for (const key of Object.keys(pluginJson)) {
    assert.ok(allowedKeys.has(key), `Unexpected top-level field in plugin.json: ${key}`);
  }

  const mcpJson = JSON.parse(fs.readFileSync(path.join(root, 'mcp_config.json'), 'utf8'));
  assert.ok(mcpJson.mcpServers?.desktop?.command);

  const hooksJson = JSON.parse(fs.readFileSync(path.join(root, 'hooks.json'), 'utf8'));
  assert.ok(Array.isArray(hooksJson['computer-use-guard']?.PreToolUse));
  console.log('[PASS] Manifest & config schemas');
}

function runHook(payload, envOverrides = {}) {
  const out = execFileSync('node', [path.join(root, 'dist', 'hook.mjs')], {
    cwd: root,
    input: JSON.stringify(payload),
    encoding: 'utf8',
    env: {
      ...process.env,
      PLUGIN_DATA: tmpData,
      PLUGIN_ROOT: root,
      ...envOverrides,
    },
  });
  return JSON.parse(out.trim());
}

function testHookPolicy() {
  // Unrelated tools should pass through with empty JSON
  assert.deepEqual(runHook({ toolCall: { name: 'read_file', args: {} } }), {});

  // Settings tool is always allowed
  assert.deepEqual(
    runHook({ toolCall: { name: 'mcp_computer-use_desktop_computer_settings', args: {} } }),
    { decision: 'allow' }
  );

  // Blocked app check via launch/focus target
  const blockedRes = runHook({
    toolCall: {
      name: 'mcp_computer-use_desktop_computer_apps',
      args: { action: 'launch', target: '1Password.exe' },
    },
  });
  assert.equal(blockedRes.decision, 'deny');

  // Allowlisted app passes cleanly
  const allowRes = runHook({
    toolCall: {
      name: 'mcp_computer-use_desktop_computer_apps',
      args: { action: 'focus', processName: 'notepad.exe' },
    },
  });
  assert.equal(allowRes.decision, 'allow');

  // Untrusted app triggers Codex-style confirmation prompt
  const askRes = runHook({
    toolCall: {
      name: 'mcp_computer-use_desktop_computer_apps',
      args: { action: 'focus', processName: 'unknown-editor.exe' },
    },
  });
  assert.equal(askRes.decision, 'force_ask');

  // Dangerous hotkey triggers force_ask even in always_allow mode
  fs.writeFileSync(
    path.join(tmpData, 'settings.json'),
    JSON.stringify({ enabled: true, approvalMode: 'always_allow', confirmDangerousHotkeys: true })
  );
  const dangerRes = runHook({
    toolCall: {
      name: 'mcp_computer-use_desktop_computer_use',
      args: { actions: [{ action: 'keypress', keys: ['Alt', 'F4'] }] },
    },
  });
  assert.equal(dangerRes.decision, 'force_ask');

  // Disabled master toggle denies desktop actions
  fs.writeFileSync(path.join(tmpData, 'settings.json'), JSON.stringify({ enabled: false }));
  const disabledRes = runHook({
    toolCall: {
      name: 'mcp_computer-use_desktop_computer_use',
      args: { actions: [{ action: 'screenshot' }] },
    },
  });
  assert.equal(disabledRes.decision, 'deny');

  // Restore defaults for subsequent MCP test
  fs.rmSync(path.join(tmpData, 'settings.json'), { force: true });
  console.log('[PASS] PreToolUse hook safety & allowlist policies');
}

async function testMcpServer() {
  const proc = spawn(
    'node',
    [path.join(root, 'dist', 'server.mjs'), '--plugin-root', root, '--data-dir', tmpData],
    { stdio: ['pipe', 'pipe', 'pipe'] }
  );

  let buffer = '';
  const pending = new Map();
  let stderr = '';
  proc.stderr.on('data', (d) => (stderr += d.toString()));
  proc.stdout.on('data', (chunk) => {
    buffer += chunk.toString('utf8');
    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (!line) continue;
      const msg = JSON.parse(line);
      if (msg.id !== undefined && pending.has(msg.id)) {
        const { resolve, reject } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) reject(new Error(msg.error.message || JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    }
  });

  let nextId = 1;
  const rpc = (method, params = {}) =>
    new Promise((resolve, reject) => {
      const id = nextId++;
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error(`RPC timeout for ${method}. stderr: ${stderr}`));
      }, 15000);
      pending.set(id, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        },
      });
      proc.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
    });

  try {
    const init = await rpc('initialize', {
      protocolVersion: '2025-03-26',
      capabilities: {},
      clientInfo: { name: 'test-client', version: '1.0.0' },
    });
    assert.equal(init.serverInfo.name, 'computer-use');
    proc.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n');

    const tools = await rpc('tools/list');
    const names = tools.tools.map((t) => t.name);
    for (const expected of [
      'computer_settings',
      'computer_apps',
      'computer_inspect',
      'computer_use',
      'app_get_state',
      'app_save_settings',
    ]) {
      assert.ok(names.includes(expected), `Missing tool: ${expected}`);
    }

    const resRead = await rpc('resources/read', { uri: 'ui://computer-use/settings.html' });
    assert.equal(resRead.contents[0].mimeType, 'text/html;profile=mcp-app');
    assert.ok(resRead.contents[0].text.includes('Always-allowed apps'));
    assert.ok(resRead.contents[0].text.includes('Pre-Action Lead-In Countdown'));
    assert.ok(!resRead.contents[0].text.includes('<!--APP_SCRIPT-->'));

    const settingsCall = await rpc('tools/call', { name: 'computer_settings', arguments: {} });
    assert.equal(settingsCall.structuredContent.settings.enabled, true);
    assert.equal(settingsCall.structuredContent.settings.preActionDelayMs, 1500);
    assert.equal(settingsCall.structuredContent.settings.postActionHoldMs, 4000);

    const saved = await rpc('tools/call', {
      name: 'app_save_settings',
      arguments: {
        settings: {
          ...settingsCall.structuredContent.settings,
          alwaysAllowedApps: ['notepad.exe', 'calc.exe'],
          preActionDelayMs: 2000,
          postActionHoldMs: 6000,
        },
      },
    });
    assert.deepEqual(saved.structuredContent.settings.alwaysAllowedApps, ['notepad.exe', 'calc.exe']);
    assert.equal(saved.structuredContent.settings.preActionDelayMs, 2000);
    assert.equal(saved.structuredContent.settings.postActionHoldMs, 6000);

    const activeCall = await rpc('tools/call', {
      name: 'computer_apps',
      arguments: { action: 'active' },
    });
    const activeInfo = JSON.parse(activeCall.content[0].text);
    const isInteractiveDesktop = !activeInfo.desktopName || activeInfo.desktopName.toLowerCase() === 'default';

    const captureCall = await rpc('tools/call', {
      name: 'computer_use',
      arguments: { actions: [{ action: 'screenshot' }], showSoM: false },
    });
    if (isInteractiveDesktop) {
      assert.equal(
        captureCall.content[0].type,
        'image',
        `Expected image response, got: ${JSON.stringify(captureCall)}`
      );
      assert.ok(captureCall.content[0].data.length > 100);
      assert.ok(fs.existsSync(path.join(tmpData, 'screenshots', 'latest.png')));
      console.log('[PASS] Bundled MCP server Stdio JSON-RPC, MCP App HTML, and live screenshot output');
    } else {
      assert.equal(captureCall.isError, true);
      const errText = String(captureCall.content?.[0]?.text || '');
      assert.ok(
        errText.includes('Screen capture failed'),
        `Expected Screen capture failed diagnostic, got: ${errText}`
      );
      console.log(
        `[PASS] Bundled MCP server Stdio JSON-RPC, MCP App HTML, and sandbox desktop diagnostic (${activeInfo.desktopName})`
      );
    }
  } finally {
    const exited = new Promise((resolve) => proc.once('exit', resolve));
    proc.stdin.end();
    setTimeout(() => {
      try { proc.kill(); } catch { /* ignore */ }
    }, 300);
    await Promise.race([exited, new Promise((r) => setTimeout(r, 2000))]);
  }
}

try {
  checkJsonFiles();
  testHookPolicy();
  await testMcpServer();
  console.log('\nALL TESTS PASSED');
} finally {
  try {
    fs.rmSync(tmpData, { recursive: true, force: true, maxRetries: 10, retryDelay: 150 });
  } catch (cleanupErr) {
    console.warn('[WARN] Temp cleanup skipped:', cleanupErr.message);
  }
}

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(
  path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')),
  '..'
);

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const plugin = JSON.parse(fs.readFileSync(path.join(root, 'plugin.json'), 'utf8'));

const version = pkg.version || plugin.version || '0.1.0';
const pluginDirName = plugin.name || 'computer-use';
const releaseRoot = path.join(root, 'release');
const stagingDir = path.join(releaseRoot, pluginDirName);
const zipName = `antigravity-computer-use-win-v${version}.zip`;
const zipPath = path.join(releaseRoot, zipName);

const RUNTIME_ENTRIES = [
  'plugin.json',
  'mcp_config.json',
  'hooks.json',
  'README.md',
  'install.ps1',
  'uninstall.ps1',
  'assets',
  'dist',
  'native',
  'rules',
  'skills',
];

function copyRecursive(src, dst) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dst, entry));
    }
  } else {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
  }
}

fs.rmSync(stagingDir, { recursive: true, force: true });
fs.rmSync(zipPath, { force: true });
fs.mkdirSync(stagingDir, { recursive: true });

for (const entry of RUNTIME_ENTRIES) {
  const src = path.join(root, entry);
  if (!fs.existsSync(src)) {
    throw new Error(`Missing required runtime entry for package: ${entry}`);
  }
  copyRecursive(src, path.join(stagingDir, entry));
}

execFileSync(
  'powershell',
  [
    '-NoProfile',
    '-ExecutionPolicy',
    'Bypass',
    '-Command',
    `Compress-Archive -Path '${stagingDir.replace(/'/g, "''")}' -DestinationPath '${zipPath.replace(/'/g, "''")}' -CompressionLevel Optimal -Force`,
  ],
  { stdio: 'inherit' }
);

const zipStat = fs.statSync(zipPath);
console.log(`Packaged plugin directory: ${stagingDir}`);
console.log(`Packaged release archive: ${zipPath} (${(zipStat.size / 1024).toFixed(1)} KB)`);

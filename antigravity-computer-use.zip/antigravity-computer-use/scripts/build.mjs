import esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const distDir = path.join(root, 'dist');
fs.mkdirSync(distDir, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'src', 'server.mjs')],
  outfile: path.join(distDir, 'server.mjs'),
  bundle: true,
  platform: 'node',
  target: 'node18',
  format: 'esm',
  banner: {
    js: "import { createRequire as __cuCreateRequire } from 'node:module'; const require = __cuCreateRequire(import.meta.url);",
  },
});

await esbuild.build({
  entryPoints: [path.join(root, 'src', 'hook.mjs')],
  outfile: path.join(distDir, 'hook.mjs'),
  bundle: true,
  platform: 'node',
  target: 'node18',
  format: 'esm',
});

const uiResult = await esbuild.build({
  entryPoints: [path.join(root, 'ui', 'app.mjs')],
  bundle: true,
  write: false,
  platform: 'browser',
  target: 'es2020',
  format: 'iife',
  minify: true,
});

const bundledScript = uiResult.outputFiles[0].text;
const templateHtml = fs.readFileSync(path.join(root, 'ui', 'template.html'), 'utf8');
const finalHtml = templateHtml.replace(
  '<!--APP_SCRIPT-->',
  () => `<script>\n${bundledScript.replace(/<\/script>/gi, '<\\/script>')}\n</script>`
);
fs.writeFileSync(path.join(distDir, 'app.html'), finalHtml, 'utf8');

console.log('Built dist/server.mjs, dist/hook.mjs, and dist/app.html');

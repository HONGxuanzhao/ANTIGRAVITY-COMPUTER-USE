param(
  [ValidateSet('Global', 'Workspace')]
  [string]$Scope = 'Global',
  [string]$WorkspacePath = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'
$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js (>= 18) is required to run this plugin. Install Node.js from https://nodejs.org/"
}

$cscCandidates = @(
  'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe',
  'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
)
$csc = $cscCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $csc) {
  throw ".NET Framework 4.x (csc.exe) was not found. Windows 10/11 is required."
}

if ($Scope -eq 'Global') {
  $TargetDir = Join-Path $env:USERPROFILE '.gemini\config\plugins\computer-use'
} else {
  $TargetDir = Join-Path $WorkspacePath '.agents\plugins\computer-use'
}

Write-Host "Installing Computer Use (Windows) plugin to: $TargetDir" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null

$Items = @('plugin.json', 'mcp_config.json', 'hooks.json', 'README.md', 'assets', 'dist', 'native', 'rules', 'skills')
foreach ($item in $Items) {
  $src = Join-Path $SourceDir $item
  if (Test-Path $src) {
    $dst = Join-Path $TargetDir $item
    if (Test-Path $src -PathType Container) {
      New-Item -ItemType Directory -Force -Path $dst | Out-Null
      Get-ChildItem -Path $src -Recurse | ForEach-Object {
        $rel = $_.FullName.Substring($src.Length).TrimStart('\', '/')
        $targetPath = Join-Path $dst $rel
        if ($_.PSIsContainer) {
          New-Item -ItemType Directory -Force -Path $targetPath | Out-Null
        } else {
          Copy-Item -Force $_.FullName $targetPath
        }
      }
    } else {
      Copy-Item -Force $src $dst
    }
  }
}

# Pre-warm native Windows driver binary so first agent call has zero compile latency
$DataDir = Join-Path $env:USERPROFILE '.gemini\config\computer-use-data'
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir 'bin') | Out-Null
$wpf = Join-Path (Split-Path $csc) 'WPF'
$exeOut = Join-Path $DataDir 'bin\win-driver.exe'
$refs = @(
  'System.dll',
  'System.Core.dll',
  'System.Drawing.dll',
  'System.Windows.Forms.dll',
  'System.Web.Extensions.dll',
  (Join-Path $wpf 'UIAutomationClient.dll'),
  (Join-Path $wpf 'UIAutomationTypes.dll'),
  (Join-Path $wpf 'WindowsBase.dll')
) -join ','

& $csc /nologo /optimize /platform:anycpu /target:exe "/out:$exeOut" "/r:$refs" (Join-Path $TargetDir 'native\ComputerUseWin.cs')
if ($LASTEXITCODE -ne 0) {
  throw "Failed to compile native Windows driver."
}

if (Get-Command agy -ErrorAction SilentlyContinue) {
  Write-Host "Validating plugin manifest with agy..." -ForegroundColor Cyan
  & agy plugin validate --strict $TargetDir
}

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "1. Open Antigravity -> Customizations -> Plugins and ensure 'Computer Use (Windows)' is enabled."
Write-Host "2. Try asking Antigravity: 'Open the Computer Use settings panel'"

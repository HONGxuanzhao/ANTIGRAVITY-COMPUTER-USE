import {
  App,
  applyDocumentTheme,
  applyHostStyleVariables,
} from '@modelcontextprotocol/ext-apps';

const app = new App({ name: 'Computer Use Settings', version: '0.1.0' }, {});

let state = {
  settings: null,
  runningWindows: [],
  scannedRunning: false,
  auditLog: [],
  previewDataUrl: '',
  previewCaption: '',
};

const els = {
  statusPill: document.getElementById('statusPill'),
  enabledToggle: document.getElementById('enabledToggle'),
  controlScopeSelect: document.getElementById('controlScopeSelect'),
  approvalModeSelect: document.getElementById('approvalModeSelect'),
  allowedChips: document.getElementById('allowedChips'),
  addAllowedInput: document.getElementById('addAllowedInput'),
  addAllowedBtn: document.getElementById('addAllowedBtn'),
  runningList: document.getElementById('runningList'),
  refreshRunningBtn: document.getElementById('refreshRunningBtn'),
  blockedChips: document.getElementById('blockedChips'),
  addBlockedInput: document.getElementById('addBlockedInput'),
  addBlockedBtn: document.getElementById('addBlockedBtn'),
  coordSpaceSelect: document.getElementById('coordSpaceSelect'),
  screenScopeSelect: document.getElementById('screenScopeSelect'),
  showSoMSelect: document.getElementById('showSoMSelect'),
  showCursorToggle: document.getElementById('showCursorToggle'),
  visualHudToggle: document.getElementById('visualHudToggle'),
  cursorMorphToggle: document.getElementById('cursorMorphToggle'),
  preActionDelaySelect: document.getElementById('preActionDelaySelect'),
  postActionHoldSelect: document.getElementById('postActionHoldSelect'),
  failsafeToggle: document.getElementById('failsafeToggle'),
  dangerousHotkeysToggle: document.getElementById('dangerousHotkeysToggle'),
  capturePreviewBtn: document.getElementById('capturePreviewBtn'),
  clearAuditBtn: document.getElementById('clearAuditBtn'),
  previewBox: document.getElementById('previewBox'),
  auditList: document.getElementById('auditList'),
  toast: document.getElementById('toast'),
};

let toastTimer = null;
function showToast(msg) {
  els.toast.textContent = msg;
  els.toast.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('show'), 1800);
}

function applyStructuredState(payload) {
  if (!payload || typeof payload !== 'object') return;
  if (payload.settings) state.settings = payload.settings;
  if (Array.isArray(payload.runningWindows)) state.runningWindows = payload.runningWindows;
  if (Array.isArray(payload.auditLog)) state.auditLog = payload.auditLog;
  if (payload.previewDataUrl) state.previewDataUrl = payload.previewDataUrl;
  if (payload.previewCaption) state.previewCaption = payload.previewCaption;
  render();
}

function renderChips(container, list, onRemove) {
  container.innerHTML = '';
  if (!list || list.length === 0) {
    const empty = document.createElement('span');
    empty.className = 'row-desc';
    empty.textContent = 'None configured';
    container.appendChild(empty);
    return;
  }
  for (const item of list) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    const label = document.createElement('span');
    label.textContent = item;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.title = `Remove ${item}`;
    btn.textContent = '×';
    btn.addEventListener('click', () => onRemove(item));
    chip.append(label, btn);
    container.appendChild(chip);
  }
}

function renderRunningWindows() {
  els.runningList.innerHTML = '';
  if (!state.runningWindows || state.runningWindows.length === 0) {
    if (state.scannedRunning) {
      const msg = document.createElement('div');
      msg.className = 'row-desc';
      msg.textContent = 'No interactive desktop windows found in current session.';
      els.runningList.appendChild(msg);
    }
    return;
  }
  const seen = new Set();
  for (const win of state.runningWindows) {
    const proc = (win.processName || '').trim();
    if (!proc || seen.has(proc.toLowerCase())) continue;
    seen.add(proc.toLowerCase());

    const row = document.createElement('div');
    row.className = 'running-item';

    const meta = document.createElement('div');
    meta.className = 'running-meta';
    const pEl = document.createElement('div');
    pEl.className = 'running-proc';
    pEl.textContent = win.isForeground ? `${proc} (Foreground)` : proc;
    const tEl = document.createElement('div');
    tEl.className = 'running-title';
    tEl.textContent = win.title || '(Untitled window)';
    meta.append(pEl, tEl);

    const alreadyAllowed = (state.settings?.alwaysAllowedApps || []).some(
      (a) => a.toLowerCase() === proc.toLowerCase()
    );
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = alreadyAllowed ? 'btn' : 'btn btn-primary';
    btn.textContent = alreadyAllowed ? 'Allowed' : '+ Allow';
    btn.disabled = alreadyAllowed;
    btn.addEventListener('click', async () => {
      await mutateAppList('alwaysAllowedApps', proc, 'add');
    });

    row.append(meta, btn);
    els.runningList.appendChild(row);
  }
}

function renderPreviewAndAudit() {
  els.previewBox.innerHTML = '';
  if (state.previewDataUrl) {
    const img = document.createElement('img');
    img.src = state.previewDataUrl;
    img.alt = state.previewCaption || 'Desktop preview';
    els.previewBox.appendChild(img);
  } else {
    const empty = document.createElement('div');
    empty.className = 'preview-empty';
    empty.textContent = 'Click "Capture preview" to test Windows DPI-aware screen capture.';
    els.previewBox.appendChild(empty);
  }

  els.auditList.innerHTML = '';
  if (!state.auditLog || state.auditLog.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'row-desc';
    empty.textContent = 'No Computer Use actions logged yet.';
    els.auditList.appendChild(empty);
    return;
  }
  for (const item of state.auditLog.slice(0, 12)) {
    const row = document.createElement('div');
    row.className = 'audit-item';
    const left = document.createElement('span');
    left.textContent = `[${item.tool || 'action'}] ${item.summary || ''} (${item.app || 'desktop'})`;
    const right = document.createElement('span');
    right.style.color = 'var(--color-text-secondary, #94a3b8)';
    right.textContent = item.timestamp ? new Date(item.timestamp).toLocaleTimeString() : '';
    row.append(left, right);
    els.auditList.appendChild(row);
  }
}

function render() {
  const s = state.settings;
  if (!s) return;

  els.statusPill.textContent = s.enabled ? 'Control Active' : 'Control Disabled';
  els.statusPill.className = `status-pill ${s.enabled ? 'on' : 'off'}`;

  els.enabledToggle.checked = Boolean(s.enabled);
  els.controlScopeSelect.value = s.controlScope || 'any_app';
  els.approvalModeSelect.value = s.approvalMode || 'ask_untrusted';
  els.coordSpaceSelect.value = s.coordSpace || 'normalized_1000';
  els.screenScopeSelect.value = s.screenScope || 'active_monitor';
  els.showSoMSelect.value = s.showSoM || 'auto';
  els.showCursorToggle.checked = Boolean(s.showCursor);
  els.visualHudToggle.checked = Boolean(s.visualHud);
  els.cursorMorphToggle.checked = Boolean(s.cursorMorph);
  els.preActionDelaySelect.value = String(s.preActionDelayMs ?? 1500);
  els.postActionHoldSelect.value = String(s.postActionHoldMs ?? 4000);
  els.failsafeToggle.checked = Boolean(s.failsafe);
  els.dangerousHotkeysToggle.checked = Boolean(s.confirmDangerousHotkeys);

  renderChips(els.allowedChips, s.alwaysAllowedApps, (item) =>
    mutateAppList('alwaysAllowedApps', item, 'remove')
  );
  renderChips(els.blockedChips, s.blockedApps, (item) =>
    mutateAppList('blockedApps', item, 'remove')
  );
  renderRunningWindows();
  renderPreviewAndAudit();
}

async function persistSettings(patch) {
  if (!state.settings) return;
  const next = { ...state.settings, ...patch };
  state.settings = next;
  render();
  try {
    const res = await app.callServerTool({
      name: 'app_save_settings',
      arguments: { settings: next },
    });
    if (res?.structuredContent) applyStructuredState(res.structuredContent);
    showToast('Settings saved');
  } catch (err) {
    showToast(`Save failed: ${err?.message || err}`);
  }
}

async function mutateAppList(field, procName, op) {
  const clean = String(procName || '').trim();
  if (!clean || !state.settings) return;
  const current = Array.isArray(state.settings[field]) ? [...state.settings[field]] : [];
  let nextList;
  if (op === 'add') {
    if (current.some((x) => x.toLowerCase() === clean.toLowerCase())) return;
    nextList = [...current, clean];
  } else {
    nextList = current.filter((x) => x.toLowerCase() !== clean.toLowerCase());
  }
  await persistSettings({ [field]: nextList });
}

els.enabledToggle.addEventListener('change', () => persistSettings({ enabled: els.enabledToggle.checked }));
els.controlScopeSelect.addEventListener('change', () =>
  persistSettings({ controlScope: els.controlScopeSelect.value })
);
els.approvalModeSelect.addEventListener('change', () =>
  persistSettings({ approvalMode: els.approvalModeSelect.value })
);
els.coordSpaceSelect.addEventListener('change', () =>
  persistSettings({ coordSpace: els.coordSpaceSelect.value })
);
els.screenScopeSelect.addEventListener('change', () =>
  persistSettings({ screenScope: els.screenScopeSelect.value })
);
els.showSoMSelect.addEventListener('change', () =>
  persistSettings({ showSoM: els.showSoMSelect.value })
);
els.showCursorToggle.addEventListener('change', () =>
  persistSettings({ showCursor: els.showCursorToggle.checked })
);
els.visualHudToggle.addEventListener('change', () =>
  persistSettings({ visualHud: els.visualHudToggle.checked })
);
els.cursorMorphToggle.addEventListener('change', () =>
  persistSettings({ cursorMorph: els.cursorMorphToggle.checked })
);
els.preActionDelaySelect.addEventListener('change', () =>
  persistSettings({ preActionDelayMs: Number(els.preActionDelaySelect.value) })
);
els.postActionHoldSelect.addEventListener('change', () =>
  persistSettings({ postActionHoldMs: Number(els.postActionHoldSelect.value) })
);
els.failsafeToggle.addEventListener('change', () =>
  persistSettings({ failsafe: els.failsafeToggle.checked })
);
els.dangerousHotkeysToggle.addEventListener('change', () =>
  persistSettings({ confirmDangerousHotkeys: els.dangerousHotkeysToggle.checked })
);

els.addAllowedBtn.addEventListener('click', async () => {
  const val = els.addAllowedInput.value.trim();
  if (!val) return;
  els.addAllowedInput.value = '';
  await mutateAppList('alwaysAllowedApps', val, 'add');
});
els.addAllowedInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') els.addAllowedBtn.click();
});

els.addBlockedBtn.addEventListener('click', async () => {
  const val = els.addBlockedInput.value.trim();
  if (!val) return;
  els.addBlockedInput.value = '';
  await mutateAppList('blockedApps', val, 'add');
});
els.addBlockedInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') els.addBlockedBtn.click();
});

els.refreshRunningBtn.addEventListener('click', async () => {
  try {
    state.scannedRunning = true;
    const res = await app.callServerTool({ name: 'app_list_running', arguments: {} });
    if (res?.structuredContent) applyStructuredState(res.structuredContent);
  } catch (err) {
    showToast(`Scan failed: ${err?.message || err}`);
  }
});

els.capturePreviewBtn.addEventListener('click', async () => {
  els.capturePreviewBtn.disabled = true;
  try {
    const res = await app.callServerTool({ name: 'app_capture_preview', arguments: {} });
    if (res?.structuredContent) applyStructuredState(res.structuredContent);
  } catch (err) {
    showToast(`Preview failed: ${err?.message || err}`);
  } finally {
    els.capturePreviewBtn.disabled = false;
  }
});

els.clearAuditBtn.addEventListener('click', async () => {
  try {
    const res = await app.callServerTool({ name: 'app_clear_audit', arguments: {} });
    if (res?.structuredContent) applyStructuredState(res.structuredContent);
  } catch (err) {
    showToast(`Clear failed: ${err?.message || err}`);
  }
});

// Register handlers BEFORE connect()
app.ontoolresult = (result) => {
  if (result?.structuredContent) {
    applyStructuredState(result.structuredContent);
  }
};

app.onhostcontextchanged = (ctx) => {
  if (ctx?.theme) applyDocumentTheme(ctx.theme);
  if (ctx?.styles?.variables) applyHostStyleVariables(ctx.styles.variables);
};

async function init() {
  await app.connect();
  const ctx = app.getHostContext();
  if (ctx?.theme) applyDocumentTheme(ctx.theme);
  if (ctx?.styles?.variables) applyHostStyleVariables(ctx.styles.variables);

  try {
    const res = await app.callServerTool({ name: 'app_get_state', arguments: {} });
    if (res?.structuredContent) applyStructuredState(res.structuredContent);
  } catch {
    // fallback if initial tool result already populated state
  }
}

init();

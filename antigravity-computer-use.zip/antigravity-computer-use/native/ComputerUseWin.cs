using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using System.Windows.Forms;

namespace ComputerUseWin
{
    internal static class NativeMethods
    {
        public static readonly IntPtr DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = new IntPtr(-4);

        [DllImport("user32.dll")]
        public static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        [DllImport("user32.dll")]
        public static extern bool SetProcessDPIAware();

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool AllowSetForegroundWindow(int dwProcessId);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        [DllImport("user32.dll")]
        public static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        public static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr")]
        public static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex);

        public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        public static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
        public const uint SWP_NOMOVE = 0x0002;
        public const uint SWP_NOSIZE = 0x0001;
        public const uint SWP_SHOWWINDOW = 0x0040;
        public const uint SWP_NOACTIVATE = 0x0010;
        public const int GWL_EXSTYLE = -20;
        public const long WS_EX_TOOLWINDOW = 0x00000080L;
        public const long WS_EX_NOACTIVATE = 0x08000000L;
        public const int WS_EX_LAYERED = 0x00080000;
        public const int WS_EX_TRANSPARENT = 0x00000020;
        public const int WS_EX_TOPMOST = 0x00000008;
        public const int SW_HIDE = 0;

        public const int ULW_ALPHA = 0x00000002;
        public const byte AC_SRC_OVER = 0x00;
        public const byte AC_SRC_ALPHA = 0x01;

        public const uint OCR_NORMAL = 32512;
        public const uint OCR_IBEAM = 32513;
        public const uint OCR_WAIT = 32514;
        public const uint OCR_HAND = 32649;
        public const uint OCR_APPSTARTING = 32650;
        public const uint SPI_SETCURSORS = 0x0057;

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool UpdateLayeredWindow(
            IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize,
            IntPtr hdcSrc, ref POINT pptSrc, uint crKey, ref BLENDFUNCTION pblend, uint dwFlags
        );

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

        [DllImport("user32.dll")]
        public static extern bool SetSystemCursor(IntPtr hcur, uint id);

        [DllImport("user32.dll")]
        public static extern IntPtr CopyIcon(IntPtr picon);

        [DllImport("user32.dll")]
        public static extern bool DestroyIcon(IntPtr hIcon);

        [DllImport("user32.dll")]
        public static extern bool GetIconInfo(IntPtr hIcon, out ICONINFO piconinfo);

        [DllImport("user32.dll")]
        public static extern IntPtr CreateIconIndirect(ref ICONINFO piconinfo);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);

        [StructLayout(LayoutKind.Sequential)]
        public struct SIZE
        {
            public int cx;
            public int cy;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct BLENDFUNCTION
        {
            public byte BlendOp;
            public byte BlendFlags;
            public byte SourceConstantAlpha;
            public byte AlphaFormat;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct ICONINFO
        {
            public bool fIcon;
            public int xHotspot;
            public int yHotspot;
            public IntPtr hbmMask;
            public IntPtr hbmColor;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll")]
        public static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("dwmapi.dll")]
        public static extern int DwmGetWindowAttribute(IntPtr hwnd, int dwAttribute, out RECT pvAttribute, int cbAttribute);

        [DllImport("user32.dll")]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll")]
        public static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        public static extern uint MapVirtualKey(uint uCode, uint uMapType);

        [DllImport("user32.dll")]
        public static extern IntPtr GetThreadDesktop(uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern bool GetUserObjectInformation(IntPtr hObj, int nIndex, StringBuilder pvInfo, int nLength, out int lpnLengthNeeded);

        public const int SW_RESTORE = 9;
        public const int SW_SHOW = 5;
        public const int SW_SHOWNOACTIVATE = 4;
        public const int DWMWA_EXTENDED_FRAME_BOUNDS = 9;
        public const int DWMWA_CLOAKED = 14;

        [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")]
        public static extern int DwmGetWindowAttributeInt(IntPtr hwnd, int dwAttribute, out int pvAttribute, int cbAttribute);

        public const uint INPUT_MOUSE = 0;
        public const uint INPUT_KEYBOARD = 1;

        public const uint MOUSEEVENTF_MOVE = 0x0001;
        public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        public const uint MOUSEEVENTF_LEFTUP = 0x0004;
        public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
        public const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        public const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
        public const uint MOUSEEVENTF_WHEEL = 0x0800;
        public const uint MOUSEEVENTF_HWHEEL = 0x1000;
        public const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
        public const uint MOUSEEVENTF_VIRTUALDESK = 0x4000;

        public const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const uint KEYEVENTF_UNICODE = 0x0004;
        public const uint KEYEVENTF_SCANCODE = 0x0008;

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public InputUnion U;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
            [FieldOffset(0)] public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public int mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT
        {
            public uint uMsg;
            public ushort wParamL;
            public ushort wParamH;
        }
    }

    internal static class KeyMapper
    {
        private static readonly Dictionary<string, ushort> KeyMap = BuildKeyMap();

        private static Dictionary<string, ushort> BuildKeyMap()
        {
            var m = new Dictionary<string, ushort>(StringComparer.OrdinalIgnoreCase);
            m["enter"] = 0x0D; m["return"] = 0x0D;
            m["tab"] = 0x09;
            m["esc"] = 0x1B; m["escape"] = 0x1B;
            m["backspace"] = 0x08; m["back"] = 0x08;
            m["space"] = 0x20; m[" "] = 0x20;
            m["delete"] = 0x2E; m["del"] = 0x2E;
            m["insert"] = 0x2D; m["ins"] = 0x2D;
            m["home"] = 0x24;
            m["end"] = 0x23;
            m["pageup"] = 0x21; m["page_up"] = 0x21; m["pgup"] = 0x21; m["prior"] = 0x21;
            m["pagedown"] = 0x22; m["page_down"] = 0x22; m["pgdn"] = 0x22; m["next"] = 0x22;
            m["left"] = 0x25; m["arrowleft"] = 0x25;
            m["up"] = 0x26; m["arrowup"] = 0x26;
            m["right"] = 0x27; m["arrowright"] = 0x27;
            m["down"] = 0x28; m["arrowdown"] = 0x28;
            m["ctrl"] = 0x11; m["control"] = 0x11; m["control_l"] = 0xA2; m["control_r"] = 0xA3; m["lctrl"] = 0xA2; m["rctrl"] = 0xA3;
            m["alt"] = 0x12; m["menu"] = 0x12; m["alt_l"] = 0xA4; m["alt_r"] = 0xA5; m["lalt"] = 0xA4; m["ralt"] = 0xA5;
            m["shift"] = 0x10; m["shift_l"] = 0xA0; m["shift_r"] = 0xA1; m["lshift"] = 0xA0; m["rshift"] = 0xA1;
            m["win"] = 0x5B; m["lwin"] = 0x5B; m["super"] = 0x5B; m["super_l"] = 0x5B; m["meta"] = 0x5B; m["cmd"] = 0x5B;
            m["rwin"] = 0x5C; m["super_r"] = 0x5C;
            m["capslock"] = 0x14; m["caps_lock"] = 0x14;
            m["numlock"] = 0x90; m["scrolllock"] = 0x91;
            m["printscreen"] = 0x2C; m["prtsc"] = 0x2C; m["snapshot"] = 0x2C;
            m["pause"] = 0x13; m["break"] = 0x13;
            m["apps"] = 0x5D; m["contextmenu"] = 0x5D;

            for (int i = 1; i <= 24; i++) m["f" + i] = (ushort)(0x6F + i);
            for (char c = 'a'; c <= 'z'; c++) m[c.ToString()] = (ushort)char.ToUpperInvariant(c);
            for (char c = '0'; c <= '9'; c++) m[c.ToString()] = (ushort)c;

            m["-"] = 0xBD; m["minus"] = 0xBD;
            m["="] = 0xBB; m["equal"] = 0xBB; m["plus"] = 0xBB;
            m["["] = 0xDB; m["bracketleft"] = 0xDB;
            m["]"] = 0xDD; m["bracketright"] = 0xDD;
            m["\\"] = 0xDC; m["backslash"] = 0xDC;
            m[";"] = 0xBA; m["semicolon"] = 0xBA;
            m["'"] = 0xDE; m["quote"] = 0xDE; m["apostrophe"] = 0xDE;
            m[","] = 0xBC; m["comma"] = 0xBC;
            m["."] = 0xBE; m["period"] = 0xBE;
            m["/"] = 0xBF; m["slash"] = 0xBF;
            m["`"] = 0xC0; m["grave"] = 0xC0; m["backquote"] = 0xC0;

            return m;
        }

        public static bool TryGetVirtualKey(string keyName, out ushort vk)
        {
            vk = 0;
            if (string.IsNullOrEmpty(keyName)) return false;
            string trimmed = keyName.Trim();
            if (KeyMap.TryGetValue(trimmed, out vk)) return true;
            if (trimmed.Length == 1)
            {
                char ch = trimmed[0];
                if (ch >= 'A' && ch <= 'Z') { vk = (ushort)ch; return true; }
                if (ch >= '0' && ch <= '9') { vk = (ushort)ch; return true; }
            }
            return false;
        }

        public static bool IsExtendedKey(ushort vk)
        {
            return vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24 ||
                   vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 ||
                   vk == 0x2D || vk == 0x2E || vk == 0x5B || vk == 0x5C ||
                   vk == 0x5D || vk == 0xA3 || vk == 0xA5 || vk == 0x2C;
        }
    }

    internal static class CursorMorpher
    {
        private static readonly object Sync = new object();
        private static bool _active = false;
        private static IntPtr _aiArrow = IntPtr.Zero;
        private static IntPtr _aiIBeam = IntPtr.Zero;
        private static bool _exitHooked = false;

        private static void EnsureExitHook()
        {
            if (_exitHooked) return;
            _exitHooked = true;
            AppDomain.CurrentDomain.ProcessExit += delegate { Restore(); };
        }

        private static IntPtr BuildAiArrowCursor()
        {
            using (var bmp = new Bitmap(64, 64, PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    using (var haloBrush = new SolidBrush(Color.FromArgb(135, 45, 212, 191)))
                    {
                        g.FillEllipse(haloBrush, 0, 0, 22, 22);
                    }
                    PointF[] pts = new PointF[]
                    {
                        new PointF(6f, 6f),
                        new PointF(6f, 52f),
                        new PointF(18f, 39f),
                        new PointF(28f, 59f),
                        new PointF(35f, 55f),
                        new PointF(25f, 36f),
                        new PointF(43f, 36f)
                    };
                    using (var shadowPen = new Pen(Color.FromArgb(200, 15, 23, 42), 5.5f))
                    using (var fill = new SolidBrush(Color.FromArgb(255, 20, 184, 166)))
                    using (var outline = new Pen(Color.White, 3.0f))
                    {
                        shadowPen.LineJoin = LineJoin.Round;
                        outline.LineJoin = LineJoin.Round;
                        g.DrawPolygon(shadowPen, pts);
                        g.FillPolygon(fill, pts);
                        g.DrawPolygon(outline, pts);
                    }
                    using (var badgeBrush = new SolidBrush(Color.FromArgb(255, 45, 212, 191)))
                    using (var badgePen = new Pen(Color.White, 2f))
                    {
                        g.FillEllipse(badgeBrush, 36f, 40f, 16f, 16f);
                        g.DrawEllipse(badgePen, 36f, 40f, 16f, 16f);
                    }
                }
                IntPtr rawIcon = bmp.GetHicon();
                try
                {
                    NativeMethods.ICONINFO info;
                    if (!NativeMethods.GetIconInfo(rawIcon, out info)) return IntPtr.Zero;
                    try
                    {
                        info.fIcon = false;
                        info.xHotspot = 6;
                        info.yHotspot = 6;
                        return NativeMethods.CreateIconIndirect(ref info);
                    }
                    finally
                    {
                        if (info.hbmColor != IntPtr.Zero) NativeMethods.DeleteObject(info.hbmColor);
                        if (info.hbmMask != IntPtr.Zero) NativeMethods.DeleteObject(info.hbmMask);
                    }
                }
                finally
                {
                    NativeMethods.DestroyIcon(rawIcon);
                }
            }
        }

        private static IntPtr BuildAiIBeamCursor()
        {
            using (var bmp = new Bitmap(56, 56, PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    using (var halo = new SolidBrush(Color.FromArgb(110, 45, 212, 191)))
                    {
                        g.FillEllipse(halo, 10, 10, 36, 36);
                    }
                    using (var shadowPen = new Pen(Color.FromArgb(200, 15, 23, 42), 7f))
                    using (var outerPen = new Pen(Color.White, 5f))
                    using (var innerPen = new Pen(Color.FromArgb(255, 20, 184, 166), 2.8f))
                    {
                        shadowPen.StartCap = LineCap.Round; shadowPen.EndCap = LineCap.Round;
                        outerPen.StartCap = LineCap.Round; outerPen.EndCap = LineCap.Round;
                        innerPen.StartCap = LineCap.Round; innerPen.EndCap = LineCap.Round;
                        g.DrawLine(shadowPen, 18, 8, 38, 8);
                        g.DrawLine(shadowPen, 18, 48, 38, 48);
                        g.DrawLine(shadowPen, 28, 8, 28, 48);
                        g.DrawLine(outerPen, 18, 8, 38, 8);
                        g.DrawLine(outerPen, 18, 48, 38, 48);
                        g.DrawLine(outerPen, 28, 8, 28, 48);
                        g.DrawLine(innerPen, 18, 8, 38, 8);
                        g.DrawLine(innerPen, 18, 48, 38, 48);
                        g.DrawLine(innerPen, 28, 8, 28, 48);
                    }
                }
                IntPtr rawIcon = bmp.GetHicon();
                try
                {
                    NativeMethods.ICONINFO info;
                    if (!NativeMethods.GetIconInfo(rawIcon, out info)) return IntPtr.Zero;
                    try
                    {
                        info.fIcon = false;
                        info.xHotspot = 28;
                        info.yHotspot = 28;
                        return NativeMethods.CreateIconIndirect(ref info);
                    }
                    finally
                    {
                        if (info.hbmColor != IntPtr.Zero) NativeMethods.DeleteObject(info.hbmColor);
                        if (info.hbmMask != IntPtr.Zero) NativeMethods.DeleteObject(info.hbmMask);
                    }
                }
                finally
                {
                    NativeMethods.DestroyIcon(rawIcon);
                }
            }
        }

        public static void Begin()
        {
            lock (Sync)
            {
                EnsureExitHook();
                if (_active) return;
                try
                {
                    if (_aiArrow == IntPtr.Zero) _aiArrow = BuildAiArrowCursor();
                    if (_aiIBeam == IntPtr.Zero) _aiIBeam = BuildAiIBeamCursor();
                    if (_aiArrow != IntPtr.Zero)
                    {
                        uint[] arrowIds = new uint[] { NativeMethods.OCR_NORMAL, NativeMethods.OCR_HAND, NativeMethods.OCR_APPSTARTING };
                        foreach (uint id in arrowIds)
                        {
                            IntPtr copy = NativeMethods.CopyIcon(_aiArrow);
                            if (copy != IntPtr.Zero) NativeMethods.SetSystemCursor(copy, id);
                        }
                    }
                    if (_aiIBeam != IntPtr.Zero)
                    {
                        IntPtr copy2 = NativeMethods.CopyIcon(_aiIBeam);
                        if (copy2 != IntPtr.Zero) NativeMethods.SetSystemCursor(copy2, NativeMethods.OCR_IBEAM);
                    }
                    _active = true;
                }
                catch { }
            }
        }

        public static void Restore()
        {
            lock (Sync)
            {
                if (!_active) return;
                try
                {
                    NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETCURSORS, 0, IntPtr.Zero, 0);
                }
                catch { }
                _active = false;
            }
        }
    }

    internal sealed class HudForm : Form
    {
        private readonly System.Windows.Forms.Timer _animTimer;
        private Rectangle _bounds = new Rectangle(0, 0, 1920, 1080);
        private Color _accent = Color.FromArgb(56, 189, 248);
        private string _statusText = "Antigravity Computer Use";
        private Point _cursorPt = Point.Empty;
        private bool _hasCursor = false;
        private Point _ripplePt = Point.Empty;
        private long _rippleStartMs = 0;
        private Color _rippleColor = Color.FromArgb(56, 189, 248);
        private Point _dragFrom = Point.Empty;
        private Point _dragTo = Point.Empty;
        private bool _hasDrag = false;
        private long _expireAtMs = 0;
        private bool _pausedForCapture = false;
        private readonly Stopwatch _clock = Stopwatch.StartNew();
        private readonly List<KeyValuePair<Point, long>> _trail = new List<KeyValuePair<Point, long>>();
        private Bitmap _cachedBmp = null;
        private int _cachedW = 0;
        private int _cachedH = 0;
        private Point _previewPt = Point.Empty;
        private bool _hasPreview = false;
        private long _progressStartMs = 0;
        private int _progressDurationMs = 0;
        private bool _showProgress = false;
        private bool _cooldownMode = false;
        private string _cooldownPrefix = "";
        private long _lastBarPaintMs = 0;

        public bool IsHudActive
        {
            get { return _clock.ElapsedMilliseconds < _expireAtMs && !_pausedForCapture; }
        }

        public HudForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Enabled = false;
            _animTimer = new System.Windows.Forms.Timer();
            _animTimer.Interval = 33;
            _animTimer.Tick += OnAnimTick;
        }

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= NativeMethods.WS_EX_LAYERED |
                              NativeMethods.WS_EX_TRANSPARENT |
                              (int)NativeMethods.WS_EX_TOOLWINDOW |
                              (int)NativeMethods.WS_EX_NOACTIVATE |
                              NativeMethods.WS_EX_TOPMOST;
                return cp;
            }
        }

        public void SetPaused(bool paused)
        {
            _pausedForCapture = paused;
            if (paused)
            {
                if (IsHandleCreated && Visible)
                {
                    NativeMethods.ShowWindow(Handle, NativeMethods.SW_HIDE);
                }
            }
            else
            {
                if (_clock.ElapsedMilliseconds < _expireAtMs)
                {
                    ShowAndPaint();
                }
            }
        }

        public void UpdateHud(Rectangle bounds, Color accent, string statusText, Point cursorPt, bool hasCursor, int holdMs)
        {
            _bounds = bounds;
            _accent = accent;
            _statusText = statusText ?? "Computer Use Active";
            _cursorPt = cursorPt;
            _hasCursor = hasCursor;
            _hasPreview = false;
            _showProgress = false;
            _cooldownMode = false;
            if (hasCursor)
            {
                _trail.Add(new KeyValuePair<Point, long>(cursorPt, _clock.ElapsedMilliseconds));
                if (_trail.Count > 24) _trail.RemoveAt(0);
            }
            _expireAtMs = _clock.ElapsedMilliseconds + Math.Max(400, holdMs);
            if (!_animTimer.Enabled) _animTimer.Start();
            if (!_pausedForCapture) ShowAndPaint();
        }

        public void ShowCountdown(Rectangle bounds, Color accent, string prefixText, Point cursorPt, bool hasCursor, Point previewPt, bool hasPreview, int totalMs, int remainingMs)
        {
            _bounds = bounds;
            _accent = accent;
            _cooldownMode = false;
            int secs = Math.Max(1, (int)Math.Ceiling(remainingMs / 1000.0));
            _statusText = string.Format("AI 操控电脑界面 · {0} ({1}s 后开始，移至左上角取消)", prefixText, secs);
            _cursorPt = cursorPt;
            _hasCursor = hasCursor;
            _previewPt = previewPt;
            _hasPreview = hasPreview;
            _showProgress = totalMs > 0;
            _progressDurationMs = totalMs;
            _progressStartMs = _clock.ElapsedMilliseconds - Math.Max(0, totalMs - remainingMs);
            _expireAtMs = _clock.ElapsedMilliseconds + Math.Max(600, remainingMs + 500);
            if (!_animTimer.Enabled) _animTimer.Start();
            if (!_pausedForCapture) ShowAndPaint();
        }

        public void ShowCooldown(Rectangle bounds, Color accent, string prefixText, Point cursorPt, bool hasCursor, int holdMs)
        {
            _bounds = bounds;
            _accent = accent;
            _cooldownPrefix = prefixText ?? "AI 已结束操作";
            _cooldownMode = true;
            _hasPreview = false;
            _cursorPt = cursorPt;
            _hasCursor = hasCursor;
            _showProgress = holdMs > 0;
            _progressStartMs = _clock.ElapsedMilliseconds;
            _progressDurationMs = Math.Max(500, holdMs);
            int secs = Math.Max(1, (int)Math.Ceiling(_progressDurationMs / 1000.0));
            _statusText = string.Format("{0} · {1}s 后界面消失", _cooldownPrefix, secs);
            _expireAtMs = _clock.ElapsedMilliseconds + _progressDurationMs;
            _lastBarPaintMs = 0;
            if (!_animTimer.Enabled) _animTimer.Start();
            if (!_pausedForCapture) ShowAndPaint();
        }

        public void TriggerRipple(Rectangle bounds, int x, int y, Color rippleColor, string statusText, int holdMs)
        {
            _bounds = bounds;
            _accent = rippleColor;
            _rippleColor = rippleColor;
            _ripplePt = new Point(x, y);
            _cursorPt = _ripplePt;
            _hasCursor = true;
            _hasPreview = false;
            _showProgress = false;
            _cooldownMode = false;
            _trail.Add(new KeyValuePair<Point, long>(_ripplePt, _clock.ElapsedMilliseconds));
            if (_trail.Count > 24) _trail.RemoveAt(0);
            _rippleStartMs = _clock.ElapsedMilliseconds;
            _statusText = statusText ?? "Clicking";
            _expireAtMs = _clock.ElapsedMilliseconds + Math.Max(600, holdMs);
            if (!_animTimer.Enabled) _animTimer.Start();
            if (!_pausedForCapture) ShowAndPaint();
        }

        public void SetDragLine(Point from, Point to, bool active)
        {
            _dragFrom = from;
            _dragTo = to;
            _hasDrag = active;
            if (!_pausedForCapture) ShowAndPaint();
        }

        private void OnAnimTick(object sender, EventArgs e)
        {
            if (_pausedForCapture) return;
            long now = _clock.ElapsedMilliseconds;
            if (now >= _expireAtMs)
            {
                _hasDrag = false;
                _hasPreview = false;
                _showProgress = false;
                _cooldownMode = false;
                _trail.Clear();
                _animTimer.Stop();
                CursorMorpher.Restore();
                if (IsHandleCreated && Visible)
                {
                    NativeMethods.ShowWindow(Handle, NativeMethods.SW_HIDE);
                }
                return;
            }
            if (_cooldownMode)
            {
                long remMs = Math.Max(0, _expireAtMs - now);
                int remSec = Math.Max(1, (int)Math.Ceiling(remMs / 1000.0));
                _statusText = string.Format("{0} · {1}s 后界面消失", _cooldownPrefix, remSec);
            }
            bool rippleActive = _rippleStartMs > 0 && (now - _rippleStartMs) < 700;
            bool trailActive = _trail.Count > 0 && (now - _trail[_trail.Count - 1].Value) < 750;
            bool fading = (_expireAtMs - now) < 650;
            bool progressTick = _showProgress && (now - _lastBarPaintMs) >= 90;
            if (rippleActive || trailActive || fading || _hasDrag || _hasPreview || progressTick)
            {
                _lastBarPaintMs = now;
                ShowAndPaint();
            }
        }

        private Bitmap GetBufferBitmap(int w, int h)
        {
            if (_cachedBmp == null || _cachedW != w || _cachedH != h)
            {
                if (_cachedBmp != null) _cachedBmp.Dispose();
                _cachedBmp = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
                _cachedW = w;
                _cachedH = h;
            }
            return _cachedBmp;
        }

        private void ShowAndPaint()
        {
            if (!IsHandleCreated) CreateHandle();
            if (_bounds.Width <= 0 || _bounds.Height <= 0) return;

            if (!Visible)
            {
                Bounds = _bounds;
                NativeMethods.ShowWindow(Handle, NativeMethods.SW_SHOWNOACTIVATE);
                NativeMethods.SetWindowPos(
                    Handle,
                    NativeMethods.HWND_TOPMOST,
                    _bounds.Left, _bounds.Top, _bounds.Width, _bounds.Height,
                    NativeMethods.SWP_NOACTIVATE | NativeMethods.SWP_NOMOVE | NativeMethods.SWP_NOSIZE | NativeMethods.SWP_SHOWWINDOW
                );
            }

            long now = _clock.ElapsedMilliseconds;
            double fadeAlpha = 1.0;
            long remaining = _expireAtMs - now;
            if (remaining < 650)
            {
                fadeAlpha = Math.Max(0.0, Math.Min(1.0, remaining / 650.0));
            }

            float uiScale = Math.Max(1.25f, _bounds.Height / 860.0f);
            Bitmap bmp = GetBufferBitmap(_bounds.Width, _bounds.Height);
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.Clear(Color.FromArgb(0, 0, 0, 0));

                    int outerA = (int)Math.Round(110 * fadeAlpha);
                    int innerA = (int)Math.Round(235 * fadeAlpha);
                    float outerW = 16f * uiScale;
                    float innerW = 4.5f * uiScale;
                    using (var outerPen = new Pen(Color.FromArgb(outerA, _accent), outerW))
                    using (var innerPen = new Pen(Color.FromArgb(innerA, _accent), innerW))
                    {
                        g.DrawRectangle(outerPen, outerW / 2f, outerW / 2f, _bounds.Width - outerW, _bounds.Height - outerW);
                        g.DrawRectangle(innerPen, innerW / 2f, innerW / 2f, _bounds.Width - innerW, _bounds.Height - innerW);
                    }

                    // Top-center large floating status pill
                    using (var font = new Font("Segoe UI", 16f * uiScale, FontStyle.Bold))
                    {
                        SizeF textSz = g.MeasureString(_statusText, font);
                        int padX = (int)Math.Round(26 * uiScale);
                        int dotSize = (int)Math.Round(13 * uiScale);
                        int pillH = (int)Math.Round(42 * uiScale);
                        int pillW = (int)Math.Ceiling(textSz.Width) + padX * 2 + dotSize + (int)Math.Round(12 * uiScale);
                        int pillX = (_bounds.Width - pillW) / 2;
                        int pillY = (int)Math.Round(16 * uiScale);
                        int textY = pillY + (int)Math.Round((pillH - textSz.Height) / 2f);
                        int pillRadius = Math.Max(6, (pillH - 2) / 2);

                        using (var shadowPath = CreateRoundedRect(new Rectangle(pillX, pillY + 4, pillW, pillH), pillRadius))
                        using (var shadowBrush = new SolidBrush(Color.FromArgb((int)Math.Round(90 * fadeAlpha), 0, 0, 0)))
                        using (var path = CreateRoundedRect(new Rectangle(pillX, pillY, pillW, pillH), pillRadius))
                        using (var bgBrush = new SolidBrush(Color.FromArgb((int)Math.Round(235 * fadeAlpha), 15, 23, 42)))
                        using (var borderPen = new Pen(Color.FromArgb((int)Math.Round(235 * fadeAlpha), _accent), 2.2f * uiScale))
                        using (var dotBrush = new SolidBrush(Color.FromArgb((int)Math.Round(255 * fadeAlpha), _accent)))
                        using (var txtBrush = new SolidBrush(Color.FromArgb((int)Math.Round(255 * fadeAlpha), 248, 250, 252)))
                        {
                            g.FillPath(shadowBrush, shadowPath);
                            g.FillPath(bgBrush, path);

                            if (_showProgress && _progressDurationMs > 0)
                            {
                                double elapsed = Math.Max(0.0, now - _progressStartMs);
                                double frac = Math.Max(0.0, Math.Min(1.0, 1.0 - (elapsed / _progressDurationMs)));
                                int barH = Math.Max(3, (int)Math.Round(4.5 * uiScale));
                                int barW = (int)Math.Round(pillW * frac);
                                if (barW > 0)
                                {
                                    g.SetClip(path);
                                    using (var barBrush = new SolidBrush(Color.FromArgb((int)Math.Round(230 * fadeAlpha), _accent)))
                                    {
                                        g.FillRectangle(barBrush, pillX, pillY + pillH - barH, barW, barH);
                                    }
                                    g.ResetClip();
                                }
                            }

                            g.DrawPath(borderPen, path);
                            g.FillEllipse(dotBrush, pillX + padX, pillY + (pillH - dotSize) / 2, dotSize, dotSize);
                            g.DrawString(_statusText, font, txtBrush, pillX + padX + dotSize + (int)Math.Round(10 * uiScale), textY);
                        }
                    }

                    // Pre-action target reticle preview
                    if (_hasPreview && _bounds.Contains(_previewPt))
                    {
                        float px = _previewPt.X - _bounds.Left;
                        float py = _previewPt.Y - _bounds.Top;
                        double pulse = 0.5 + 0.5 * Math.Sin((now % 600) / 600.0 * Math.PI * 2.0);
                        float pr = (float)((22 + pulse * 10) * uiScale);
                        using (var pFill = new SolidBrush(Color.FromArgb((int)Math.Round(55 * fadeAlpha), _accent)))
                        using (var pPen = new Pen(Color.FromArgb((int)Math.Round(235 * fadeAlpha), _accent), 3f * uiScale))
                        using (var tFont = new Font("Segoe UI", 9.5f * uiScale, FontStyle.Bold))
                        using (var tBg = new SolidBrush(Color.FromArgb((int)Math.Round(230 * fadeAlpha), 15, 23, 42)))
                        using (var tFg = new SolidBrush(Color.FromArgb((int)Math.Round(255 * fadeAlpha), _accent)))
                        {
                            pPen.DashStyle = DashStyle.Dash;
                            g.FillEllipse(pFill, px - pr, py - pr, pr * 2, pr * 2);
                            g.DrawEllipse(pPen, px - pr, py - pr, pr * 2, pr * 2);
                            g.DrawLine(pPen, px - pr - 8f * uiScale, py, px + pr + 8f * uiScale, py);
                            g.DrawLine(pPen, px, py - pr - 8f * uiScale, px, py + pr + 8f * uiScale);
                            string lbl = "目标";
                            SizeF lsz = g.MeasureString(lbl, tFont);
                            float lx = px - lsz.Width / 2f;
                            float ly = py - pr - lsz.Height - 6f * uiScale;
                            g.FillRectangle(tBg, lx - 4, ly - 2, lsz.Width + 8, lsz.Height + 4);
                            g.DrawString(lbl, tFont, tFg, lx, ly);
                        }
                    }

                    // Glowing motion comet trail
                    var aliveTrail = new List<PointF>();
                    for (int i = 0; i < _trail.Count; i++)
                    {
                        long age = now - _trail[i].Value;
                        if (age >= 0 && age < 750)
                        {
                            aliveTrail.Add(new PointF(_trail[i].Key.X - _bounds.Left, _trail[i].Key.Y - _bounds.Top));
                        }
                    }
                    if (aliveTrail.Count >= 2)
                    {
                        for (int i = 1; i < aliveTrail.Count; i++)
                        {
                            float frac = (float)i / aliveTrail.Count;
                            int tAlpha = (int)Math.Round(210 * frac * fadeAlpha);
                            float tWidth = Math.Max(2f, 7f * uiScale * frac);
                            using (var trailPen = new Pen(Color.FromArgb(tAlpha, _accent), tWidth))
                            {
                                trailPen.StartCap = LineCap.Round;
                                trailPen.EndCap = LineCap.Round;
                                g.DrawLine(trailPen, aliveTrail[i - 1], aliveTrail[i]);
                            }
                        }
                    }

                    // Drag path trail
                    if (_hasDrag)
                    {
                        float fx = _dragFrom.X - _bounds.Left;
                        float fy = _dragFrom.Y - _bounds.Top;
                        float tx = _dragTo.X - _bounds.Left;
                        float ty = _dragTo.Y - _bounds.Top;
                        using (var dragPen = new Pen(Color.FromArgb((int)Math.Round(220 * fadeAlpha), _accent), 3.5f * uiScale))
                        {
                            dragPen.DashStyle = DashStyle.Dash;
                            g.DrawLine(dragPen, fx, fy, tx, ty);
                        }
                    }

                    // Live glowing AI cursor halo + badge
                    if (_hasCursor && _bounds.Contains(_cursorPt))
                    {
                        float cx = _cursorPt.X - _bounds.Left;
                        float cy = _cursorPt.Y - _bounds.Top;
                        float r = 24f * uiScale;
                        using (var haloBrush = new SolidBrush(Color.FromArgb((int)Math.Round(65 * fadeAlpha), _accent)))
                        using (var ringPen = new Pen(Color.FromArgb((int)Math.Round(235 * fadeAlpha), _accent), 3f * uiScale))
                        using (var tagFont = new Font("Segoe UI", 9.5f * uiScale, FontStyle.Bold))
                        using (var tagBg = new SolidBrush(Color.FromArgb((int)Math.Round(235 * fadeAlpha), _accent)))
                        using (var tagFg = new SolidBrush(Color.FromArgb((int)Math.Round(255 * fadeAlpha), 15, 23, 42)))
                        {
                            g.FillEllipse(haloBrush, cx - r, cy - r, r * 2, r * 2);
                            g.DrawEllipse(ringPen, cx - r, cy - r, r * 2, r * 2);
                            float bx = cx + 18f * uiScale;
                            float by = cy + 18f * uiScale;
                            float bw = 28f * uiScale;
                            float bh = 18f * uiScale;
                            g.FillRectangle(tagBg, bx, by, bw, bh);
                            g.DrawString("AI", tagFont, tagFg, bx + 4f * uiScale, by + 1f);
                        }
                    }

                    // Expanding dual-ring click ripple
                    if (_rippleStartMs > 0)
                    {
                        long age = now - _rippleStartMs;
                        if (age >= 0 && age < 700 && _bounds.Contains(_ripplePt))
                        {
                            double t = age / 700.0;
                            float radius = (float)((14 + t * 56) * uiScale);
                            float innerR = (float)((6 + t * 34) * uiScale);
                            int rAlpha = (int)Math.Round((1.0 - t) * 245 * fadeAlpha);
                            float rx = _ripplePt.X - _bounds.Left;
                            float ry = _ripplePt.Y - _bounds.Top;
                            using (var rPen = new Pen(Color.FromArgb(rAlpha, _rippleColor), 4f * uiScale))
                            using (var rInner = new Pen(Color.FromArgb(rAlpha, Color.White), 2f * uiScale))
                            using (var rFill = new SolidBrush(Color.FromArgb(rAlpha / 4, _rippleColor)))
                            {
                                g.FillEllipse(rFill, rx - radius, ry - radius, radius * 2, radius * 2);
                                g.DrawEllipse(rPen, rx - radius, ry - radius, radius * 2, radius * 2);
                                g.DrawEllipse(rInner, rx - innerR, ry - innerR, innerR * 2, innerR * 2);
                            }
                        }
                    }
                }

                PushBitmap(bmp);
            }
        }

        private void PushBitmap(Bitmap bmp)
        {
            IntPtr screenDc = NativeMethods.GetDC(IntPtr.Zero);
            IntPtr memDc = NativeMethods.CreateCompatibleDC(screenDc);
            IntPtr hBmp = IntPtr.Zero;
            IntPtr oldBmp = IntPtr.Zero;
            try
            {
                hBmp = bmp.GetHbitmap(Color.FromArgb(0));
                oldBmp = NativeMethods.SelectObject(memDc, hBmp);
                var ptDst = new NativeMethods.POINT { X = _bounds.Left, Y = _bounds.Top };
                var sz = new NativeMethods.SIZE { cx = bmp.Width, cy = bmp.Height };
                var ptSrc = new NativeMethods.POINT { X = 0, Y = 0 };
                var blend = new NativeMethods.BLENDFUNCTION
                {
                    BlendOp = NativeMethods.AC_SRC_OVER,
                    BlendFlags = 0,
                    SourceConstantAlpha = 255,
                    AlphaFormat = NativeMethods.AC_SRC_ALPHA
                };
                NativeMethods.UpdateLayeredWindow(Handle, screenDc, ref ptDst, ref sz, memDc, ref ptSrc, 0, ref blend, NativeMethods.ULW_ALPHA);
            }
            finally
            {
                if (oldBmp != IntPtr.Zero) NativeMethods.SelectObject(memDc, oldBmp);
                if (hBmp != IntPtr.Zero) NativeMethods.DeleteObject(hBmp);
                NativeMethods.DeleteDC(memDc);
                NativeMethods.ReleaseDC(IntPtr.Zero, screenDc);
            }
        }

        private static GraphicsPath CreateRoundedRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.Left, r.Top, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    internal static class HudOverlay
    {
        private static readonly object Sync = new object();
        private static HudForm _form = null;
        private static Thread _thread = null;
        private static readonly ManualResetEventSlim Ready = new ManualResetEventSlim(false);
        private static bool _enabledForProcess = false;

        public static void EnableForStdio()
        {
            _enabledForProcess = true;
        }

        private static bool EnsureForm()
        {
            if (!_enabledForProcess) return false;
            lock (Sync)
            {
                if (_form != null && !_form.IsDisposed) return true;
                if (_thread == null)
                {
                    Ready.Reset();
                    _thread = new Thread(delegate()
                    {
                        try
                        {
                            _form = new HudForm();
                            var h = _form.Handle;
                            Ready.Set();
                            Application.Run(_form);
                        }
                        catch
                        {
                            Ready.Set();
                        }
                    });
                    _thread.IsBackground = true;
                    _thread.SetApartmentState(ApartmentState.STA);
                    _thread.Start();
                }
            }
            Ready.Wait(1500);
            return _form != null && _form.IsHandleCreated && !_form.IsDisposed;
        }

        public static bool IsActive()
        {
            if (_form == null || _form.IsDisposed || !_form.IsHandleCreated) return false;
            try { return _form.IsHudActive; } catch { return false; }
        }

        public static void ShowState(Rectangle bounds, Color accent, string statusText, Point cursorPt, bool hasCursor, int holdMs)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.BeginInvoke(new Action(delegate()
                {
                    _form.UpdateHud(bounds, accent, statusText, cursorPt, hasCursor, holdMs);
                }));
            }
            catch { }
        }

        public static void ShowCountdownSync(Rectangle bounds, Color accent, string prefixText, Point cursorPt, bool hasCursor, Point previewPt, bool hasPreview, int totalMs, int remainingMs)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.Invoke(new Action(delegate()
                {
                    _form.ShowCountdown(bounds, accent, prefixText, cursorPt, hasCursor, previewPt, hasPreview, totalMs, remainingMs);
                }));
            }
            catch { }
        }

        public static void ShowCooldown(Rectangle bounds, Color accent, string prefixText, Point cursorPt, bool hasCursor, int holdMs)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.BeginInvoke(new Action(delegate()
                {
                    _form.ShowCooldown(bounds, accent, prefixText, cursorPt, hasCursor, holdMs);
                }));
            }
            catch { }
        }

        public static void ShowStateSync(Rectangle bounds, Color accent, string statusText, Point cursorPt, bool hasCursor, int holdMs)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.Invoke(new Action(delegate()
                {
                    _form.UpdateHud(bounds, accent, statusText, cursorPt, hasCursor, holdMs);
                }));
            }
            catch { }
        }

        public static void TriggerRipple(Rectangle bounds, int x, int y, Color rippleColor, string statusText, int holdMs)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.Invoke(new Action(delegate()
                {
                    _form.TriggerRipple(bounds, x, y, rippleColor, statusText, holdMs);
                }));
            }
            catch { }
        }

        public static void SetDragLine(Point from, Point to, bool active)
        {
            if (!EnsureForm()) return;
            try
            {
                _form.BeginInvoke(new Action(delegate()
                {
                    _form.SetDragLine(from, to, active);
                }));
            }
            catch { }
        }

        public static void PauseForCapture()
        {
            if (_form == null || _form.IsDisposed || !_form.IsHandleCreated) return;
            try
            {
                _form.Invoke(new Action(delegate()
                {
                    _form.SetPaused(true);
                }));
                Thread.Sleep(15);
            }
            catch { }
        }

        public static void ResumeAfterCapture()
        {
            if (_form == null || _form.IsDisposed || !_form.IsHandleCreated) return;
            try
            {
                _form.BeginInvoke(new Action(delegate()
                {
                    _form.SetPaused(false);
                }));
            }
            catch { }
        }
    }

    internal sealed class Program
    {
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 64 * 1024 * 1024 };

        [STAThread]
        private static int Main(string[] args)
        {
            InitDpi();
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            if (args.Length > 0 && args[0] == "--stdio")
            {
                RunStdioLoop();
                return 0;
            }

            try
            {
                string cmd = args.Length > 0 ? args[0] : "foreground";
                string payloadRaw = args.Length > 1 ? args[1] : "{}";
                if (payloadRaw == "-")
                {
                    payloadRaw = Console.In.ReadToEnd();
                }

                Dictionary<string, object> payload = ParseDict(payloadRaw);
                object res = Dispatch(cmd, payload);
                Console.WriteLine(Json.Serialize(res));
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(Json.Serialize(new Dictionary<string, object>
                {
                    { "ok", false },
                    { "error", ex.Message },
                    { "type", ex.GetType().FullName }
                }));
                return 1;
            }
        }

        private static void InitDpi()
        {
            try
            {
                if (!NativeMethods.SetProcessDpiAwarenessContext(NativeMethods.DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2))
                {
                    NativeMethods.SetProcessDPIAware();
                }
            }
            catch
            {
                try { NativeMethods.SetProcessDPIAware(); } catch { }
            }
        }

        private static void RunStdioLoop()
        {
            if (string.Equals(GetCurrentDesktopName(), "Default", StringComparison.OrdinalIgnoreCase))
            {
                HudOverlay.EnableForStdio();
            }
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                string id = "";
                try
                {
                    Dictionary<string, object> req = ParseDict(line);
                    id = GetString(req, "id", "");
                    string cmd = GetString(req, "cmd", "");
                    Dictionary<string, object> payload = GetDict(req, "payload");
                    object result = Dispatch(cmd, payload);
                    var envelope = new Dictionary<string, object>();
                    envelope["id"] = id;
                    envelope["ok"] = true;
                    envelope["result"] = result;
                    Console.WriteLine(Json.Serialize(envelope));
                    Console.Out.Flush();
                }
                catch (Exception ex)
                {
                    var err = new Dictionary<string, object>();
                    err["id"] = id;
                    err["ok"] = false;
                    err["error"] = ex.Message;
                    Console.WriteLine(Json.Serialize(err));
                    Console.Out.Flush();
                }
            }
        }

        private static object Dispatch(string cmd, Dictionary<string, object> payload)
        {
            switch ((cmd ?? "").ToLowerInvariant())
            {
                case "ping":
                    return new Dictionary<string, object> { { "pong", true } };
                case "foreground":
                    return GetForegroundInfo();
                case "list_windows":
                    return ListWindows();
                case "focus_window":
                    return FocusWindow(payload);
                case "launch_app":
                    return LaunchApp(payload);
                case "inspect":
                    return InspectForeground(payload);
                case "capture":
                    return CaptureAndAnnotate(payload);
                case "act":
                    return ExecuteActions(payload);
                default:
                    throw new InvalidOperationException("Unknown command: " + cmd);
            }
        }

        private static Dictionary<string, object> GetForegroundInfo()
        {
            IntPtr hwnd = NativeMethods.GetForegroundWindow();
            NativeMethods.POINT pt;
            NativeMethods.GetCursorPos(out pt);
            var info = DescribeWindow(hwnd);
            if (info == null)
            {
                info = new Dictionary<string, object>
                {
                    { "hwnd", "0" },
                    { "pid", 0 },
                    { "processName", "" },
                    { "title", "" },
                    { "bounds", new Dictionary<string, object> { { "x", 0 }, { "y", 0 }, { "w", 0 }, { "h", 0 } } },
                    { "isForeground", true }
                };
            }
            info["cursor"] = new Dictionary<string, object> { { "x", pt.X }, { "y", pt.Y } };
            info["desktopName"] = GetCurrentDesktopName();
            info["virtualScreen"] = RectToDict(SystemInformation.VirtualScreen);
            info["primaryScreen"] = RectToDict(Screen.PrimaryScreen.Bounds);
            return info;
        }

        private static string GetCurrentDesktopName()
        {
            try
            {
                IntPtr hDesk = NativeMethods.GetThreadDesktop(NativeMethods.GetCurrentThreadId());
                var sb = new StringBuilder(256);
                int needed;
                if (NativeMethods.GetUserObjectInformation(hDesk, 2, sb, sb.Capacity * 2, out needed))
                {
                    return sb.ToString();
                }
            }
            catch { }
            return "";
        }

        private static Dictionary<string, object> DescribeWindow(IntPtr hwnd)
        {
            if (hwnd == IntPtr.Zero) return null;
            int len = NativeMethods.GetWindowTextLength(hwnd);
            var sb = new StringBuilder(Math.Max(256, len + 2));
            NativeMethods.GetWindowText(hwnd, sb, sb.Capacity);
            string title = sb.ToString();

            uint pid;
            NativeMethods.GetWindowThreadProcessId(hwnd, out pid);
            string procName = "";
            try
            {
                using (Process p = Process.GetProcessById((int)pid))
                {
                    procName = p.ProcessName + ".exe";
                }
            }
            catch { }

            NativeMethods.RECT rect;
            if (NativeMethods.DwmGetWindowAttribute(hwnd, NativeMethods.DWMWA_EXTENDED_FRAME_BOUNDS, out rect, Marshal.SizeOf(typeof(NativeMethods.RECT))) != 0)
            {
                NativeMethods.GetWindowRect(hwnd, out rect);
            }

            return new Dictionary<string, object>
            {
                { "hwnd", hwnd.ToInt64().ToString() },
                { "pid", (int)pid },
                { "processName", procName },
                { "title", title },
                { "bounds", new Dictionary<string, object>
                    {
                        { "x", rect.Left },
                        { "y", rect.Top },
                        { "w", Math.Max(0, rect.Right - rect.Left) },
                        { "h", Math.Max(0, rect.Bottom - rect.Top) }
                    }
                },
                { "isMinimized", NativeMethods.IsIconic(hwnd) }
            };
        }

        private static List<Dictionary<string, object>> ListWindows()
        {
            IntPtr fg = NativeMethods.GetForegroundWindow();
            var list = new List<Dictionary<string, object>>();
            NativeMethods.EnumWindows((hwnd, lParam) =>
            {
                if (!NativeMethods.IsWindowVisible(hwnd)) return true;
                int cloaked = 0;
                if (NativeMethods.DwmGetWindowAttributeInt(hwnd, NativeMethods.DWMWA_CLOAKED, out cloaked, sizeof(int)) == 0 && cloaked != 0)
                {
                    return true;
                }
                long exStyle = NativeMethods.GetWindowLongPtr(hwnd, NativeMethods.GWL_EXSTYLE).ToInt64();
                if (hwnd != fg && ((exStyle & NativeMethods.WS_EX_TOOLWINDOW) != 0 || (exStyle & NativeMethods.WS_EX_NOACTIVATE) != 0))
                {
                    return true;
                }
                int len = NativeMethods.GetWindowTextLength(hwnd);
                if (len <= 0) return true;
                Dictionary<string, object> info = DescribeWindow(hwnd);
                if (info == null) return true;
                string procLower = GetString(info, "processName", "").ToLowerInvariant();
                if (hwnd != fg && procLower == "nvidia overlay.exe") return true;
                Dictionary<string, object> b = (Dictionary<string, object>)info["bounds"];
                int w = Convert.ToInt32(b["w"]);
                int h = Convert.ToInt32(b["h"]);
                if (w < 40 || h < 20) return true;
                info["isForeground"] = (hwnd == fg);
                list.Add(info);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        private static Dictionary<string, object> FocusWindow(Dictionary<string, object> payload)
        {
            string hwndStr = GetString(payload, "hwnd", "");
            string procMatch = GetString(payload, "processName", "");
            string titleMatch = GetString(payload, "titleContains", "");

            IntPtr target = IntPtr.Zero;
            if (!string.IsNullOrEmpty(hwndStr))
            {
                long val;
                if (long.TryParse(hwndStr, out val)) target = new IntPtr(val);
            }

            if (target == IntPtr.Zero)
            {
                List<Dictionary<string, object>> windows = ListWindows();
                foreach (var w in windows)
                {
                    string p = GetString(w, "processName", "");
                    string t = GetString(w, "title", "");
                    bool pOk = string.IsNullOrEmpty(procMatch) ||
                               p.IndexOf(procMatch, StringComparison.OrdinalIgnoreCase) >= 0 ||
                               p.Replace(".exe", "").Equals(procMatch.Replace(".exe", ""), StringComparison.OrdinalIgnoreCase);
                    bool tOk = string.IsNullOrEmpty(titleMatch) ||
                               t.IndexOf(titleMatch, StringComparison.OrdinalIgnoreCase) >= 0;
                    if (pOk && tOk)
                    {
                        target = new IntPtr(long.Parse(GetString(w, "hwnd", "0")));
                        break;
                    }
                }
            }

            if (target == IntPtr.Zero)
            {
                throw new InvalidOperationException("No matching window found to focus.");
            }

            ForceForeground(target);
            Thread.Sleep(120);
            Dictionary<string, object> fg = GetForegroundInfo();
            fg["focused"] = true;
            if (GetBool(payload, "visualHud", true))
            {
                Rectangle hudBounds = ResolveCaptureRect(GetString(payload, "screenScope", "active_monitor"));
                int postHoldMs = Math.Max(500, GetInt(payload, "postActionHoldMs", 4500));
                string proc = GetString(fg, "processName", "");
                HudOverlay.ShowCooldown(
                    hudBounds,
                    Color.FromArgb(20, 184, 166),
                    "AI 正在操控电脑 · 已聚焦 " + proc,
                    Point.Empty,
                    false,
                    postHoldMs
                );
            }
            return fg;
        }

        private static void ForceForeground(IntPtr hWnd)
        {
            if (NativeMethods.IsIconic(hWnd))
            {
                NativeMethods.ShowWindow(hWnd, NativeMethods.SW_RESTORE);
            }
            else
            {
                NativeMethods.ShowWindow(hWnd, NativeMethods.SW_SHOW);
            }

            IntPtr fg = NativeMethods.GetForegroundWindow();
            uint unused;
            uint fgThread = NativeMethods.GetWindowThreadProcessId(fg, out unused);
            uint curThread = NativeMethods.GetCurrentThreadId();
            uint targetPid;
            uint targetThread = NativeMethods.GetWindowThreadProcessId(hWnd, out targetPid);
            NativeMethods.AllowSetForegroundWindow((int)targetPid);

            bool attachedFg = false;
            bool attachedTarget = false;
            try
            {
                if (fgThread != 0 && fgThread != curThread)
                {
                    attachedFg = NativeMethods.AttachThreadInput(curThread, fgThread, true);
                }
                if (targetThread != 0 && targetThread != curThread && targetThread != fgThread)
                {
                    attachedTarget = NativeMethods.AttachThreadInput(curThread, targetThread, true);
                }
                NativeMethods.SetWindowPos(
                    hWnd,
                    NativeMethods.HWND_TOPMOST,
                    0, 0, 0, 0,
                    NativeMethods.SWP_NOMOVE | NativeMethods.SWP_NOSIZE | NativeMethods.SWP_SHOWWINDOW
                );
                NativeMethods.SetWindowPos(
                    hWnd,
                    NativeMethods.HWND_NOTOPMOST,
                    0, 0, 0, 0,
                    NativeMethods.SWP_NOMOVE | NativeMethods.SWP_NOSIZE | NativeMethods.SWP_SHOWWINDOW
                );
                NativeMethods.BringWindowToTop(hWnd);
                NativeMethods.SetForegroundWindow(hWnd);
                NativeMethods.SwitchToThisWindow(hWnd, true);
            }
            finally
            {
                if (attachedTarget) NativeMethods.AttachThreadInput(curThread, targetThread, false);
                if (attachedFg) NativeMethods.AttachThreadInput(curThread, fgThread, false);
            }
        }

        private static Dictionary<string, object> LaunchApp(Dictionary<string, object> payload)
        {
            string target = GetString(payload, "target", "");
            string arguments = GetString(payload, "args", "");
            if (string.IsNullOrWhiteSpace(target))
            {
                throw new ArgumentException("Missing 'target' for launch_app.");
            }

            var beforeHwnds = new HashSet<string>();
            foreach (var w in ListWindows())
            {
                beforeHwnds.Add(GetString(w, "hwnd", ""));
            }

            var psi = new ProcessStartInfo
            {
                FileName = target,
                Arguments = arguments,
                UseShellExecute = true
            };
            Process p = Process.Start(psi);
            if (p != null)
            {
                try { p.WaitForInputIdle(1500); } catch { }
            }

            string targetBase = Path.GetFileNameWithoutExtension(target).ToLowerInvariant();
            IntPtr discovered = IntPtr.Zero;
            var sw = Stopwatch.StartNew();
            while (sw.ElapsedMilliseconds < 2200 && discovered == IntPtr.Zero)
            {
                Thread.Sleep(180);
                foreach (var w in ListWindows())
                {
                    string hStr = GetString(w, "hwnd", "");
                    string pName = GetString(w, "processName", "").ToLowerInvariant();
                    if (!beforeHwnds.Contains(hStr) ||
                        (!string.IsNullOrEmpty(targetBase) && pName.Contains(targetBase)))
                    {
                        long hv;
                        if (long.TryParse(hStr, out hv) && hv != 0)
                        {
                            discovered = new IntPtr(hv);
                            break;
                        }
                    }
                }
            }

            if (discovered != IntPtr.Zero)
            {
                ForceForeground(discovered);
                Thread.Sleep(180);
            }

            Dictionary<string, object> fg = GetForegroundInfo();
            if (GetBool(payload, "visualHud", true))
            {
                Rectangle hudBounds = ResolveCaptureRect(GetString(payload, "screenScope", "active_monitor"));
                int postHoldMs = Math.Max(500, GetInt(payload, "postActionHoldMs", 4500));
                string proc = GetString(fg, "processName", target);
                HudOverlay.ShowCooldown(
                    hudBounds,
                    Color.FromArgb(20, 184, 166),
                    "AI 正在操控电脑 · 已启动 " + proc,
                    Point.Empty,
                    false,
                    postHoldMs
                );
            }
            return fg;
        }

        private static Rectangle ResolveCaptureRect(string screenScope)
        {
            if (string.Equals(screenScope, "virtual", StringComparison.OrdinalIgnoreCase))
            {
                return SystemInformation.VirtualScreen;
            }
            if (string.Equals(screenScope, "primary", StringComparison.OrdinalIgnoreCase))
            {
                return Screen.PrimaryScreen.Bounds;
            }
            IntPtr fg = NativeMethods.GetForegroundWindow();
            if (fg != IntPtr.Zero)
            {
                Screen scr = Screen.FromHandle(fg);
                if (scr != null) return scr.Bounds;
            }
            return Screen.PrimaryScreen.Bounds;
        }

        private static List<Dictionary<string, object>> CollectUiaElements(IntPtr hwnd, Rectangle captureBounds, int maxElements)
        {
            var results = new List<Dictionary<string, object>>();
            if (hwnd == IntPtr.Zero) return results;

            AutomationElement root = null;
            try { root = AutomationElement.FromHandle(hwnd); } catch { return results; }
            if (root == null) return results;

            var sw = Stopwatch.StartNew();
            var queue = new Queue<KeyValuePair<AutomationElement, int>>();
            queue.Enqueue(new KeyValuePair<AutomationElement, int>(root, 0));

            while (queue.Count > 0 && results.Count < maxElements && sw.ElapsedMilliseconds < 950)
            {
                KeyValuePair<AutomationElement, int> item = queue.Dequeue();
                AutomationElement el = item.Key;
                int depth = item.Value;
                if (depth > 22) continue;

                try
                {
                    AutomationElement.AutomationElementInformation cur = el.Current;
                    if (!cur.IsOffscreen && cur.IsEnabled)
                    {
                        System.Windows.Rect r = cur.BoundingRectangle;
                        if (!r.IsEmpty && r.Width >= 8 && r.Height >= 8 && r.Width < captureBounds.Width && r.Height < captureBounds.Height)
                        {
                            int rx = (int)Math.Round(r.X);
                            int ry = (int)Math.Round(r.Y);
                            int rw = (int)Math.Round(r.Width);
                            int rh = (int)Math.Round(r.Height);
                            var rect = new Rectangle(rx, ry, rw, rh);
                            if (captureBounds.IntersectsWith(rect))
                            {
                                ControlType ct = cur.ControlType;
                                bool interactive =
                                    ct == ControlType.Button ||
                                    ct == ControlType.Edit ||
                                    ct == ControlType.ComboBox ||
                                    ct == ControlType.CheckBox ||
                                    ct == ControlType.RadioButton ||
                                    ct == ControlType.MenuItem ||
                                    ct == ControlType.TabItem ||
                                    ct == ControlType.ListItem ||
                                    ct == ControlType.TreeItem ||
                                    ct == ControlType.Hyperlink ||
                                    ct == ControlType.Slider ||
                                    ct == ControlType.SplitButton ||
                                    ct == ControlType.Document ||
                                    ((ct == ControlType.Custom || ct == ControlType.Text) && cur.IsKeyboardFocusable && !string.IsNullOrWhiteSpace(cur.Name));

                                if (interactive)
                                {
                                    int id = results.Count + 1;
                                    int cx = rx + rw / 2;
                                    int cy = ry + rh / 2;
                                    double normX = Math.Round(((cx - captureBounds.Left) * 1000.0) / Math.Max(1, captureBounds.Width), 1);
                                    double normY = Math.Round(((cy - captureBounds.Top) * 1000.0) / Math.Max(1, captureBounds.Height), 1);

                                    results.Add(new Dictionary<string, object>
                                    {
                                        { "id", id },
                                        { "type", ct.ProgrammaticName.Replace("ControlType.", "") },
                                        { "name", (cur.Name ?? "").Trim() },
                                        { "automationId", (cur.AutomationId ?? "").Trim() },
                                        { "bbox", new Dictionary<string, object> { { "x", rx }, { "y", ry }, { "w", rw }, { "h", rh } } },
                                        { "centerScreen", new Dictionary<string, object> { { "x", cx }, { "y", cy } } },
                                        { "centerNorm", new Dictionary<string, object> { { "x", normX }, { "y", normY } } }
                                    });
                                }
                            }
                        }
                    }

                    TreeWalker walker = TreeWalker.ControlViewWalker;
                    AutomationElement child = walker.GetFirstChild(el);
                    int childGuard = 0;
                    while (child != null && childGuard < 80 && sw.ElapsedMilliseconds < 900)
                    {
                        queue.Enqueue(new KeyValuePair<AutomationElement, int>(child, depth + 1));
                        child = walker.GetNextSibling(child);
                        childGuard++;
                    }
                }
                catch { }
            }

            return results;
        }

        private static Dictionary<string, object> InspectForeground(Dictionary<string, object> payload)
        {
            string screenScope = GetString(payload, "screenScope", "active_monitor");
            int maxElements = GetInt(payload, "maxElements", 80);
            Rectangle bounds = ResolveCaptureRect(screenScope);
            IntPtr fg = NativeMethods.GetForegroundWindow();
            List<Dictionary<string, object>> elements = CollectUiaElements(fg, bounds, maxElements);
            Dictionary<string, object> fgInfo = GetForegroundInfo();
            fgInfo["captureBounds"] = RectToDict(bounds);
            fgInfo["elements"] = elements;
            return fgInfo;
        }

        private static Dictionary<string, object> CaptureAndAnnotate(Dictionary<string, object> payload)
        {
            string screenScope = GetString(payload, "screenScope", "active_monitor");
            int maxWidth = Math.Max(640, GetInt(payload, "maxImageWidth", 1440));
            bool showSoM = GetBool(payload, "showSoM", false);
            bool showCursor = GetBool(payload, "showCursor", true);
            bool showGrid = GetBool(payload, "showGrid", false);
            string outputPath = GetString(payload, "outputPath", "");

            bool visualHud = GetBool(payload, "visualHud", false);
            bool cursorMorph = GetBool(payload, "cursorMorph", false);
            bool fromAct = GetBool(payload, "_fromAct", false);
            int postHoldMs = Math.Max(500, GetInt(payload, "postActionHoldMs", 4500));

            Rectangle bounds = ResolveCaptureRect(screenScope);
            if (visualHud && !fromAct)
            {
                bool interactive = string.Equals(GetCurrentDesktopName(), "Default", StringComparison.OrdinalIgnoreCase);
                if (interactive && cursorMorph)
                {
                    CursorMorpher.Begin();
                }
                NativeMethods.POINT cur;
                NativeMethods.GetCursorPos(out cur);
                HudOverlay.ShowCooldown(
                    bounds,
                    Color.FromArgb(20, 184, 166),
                    "AI 正在操控电脑 · 读取界面元素",
                    new Point(cur.X, cur.Y),
                    true,
                    postHoldMs
                );
            }

            IntPtr fg = NativeMethods.GetForegroundWindow();
            List<Dictionary<string, object>> elements = showSoM ? CollectUiaElements(fg, bounds, 80) : new List<Dictionary<string, object>>();

            NativeMethods.POINT cursorPt;
            NativeMethods.GetCursorPos(out cursorPt);

            using (var rawBmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb))
            {
                using (Graphics g = Graphics.FromImage(rawBmp))
                {
                    HudOverlay.PauseForCapture();
                    try
                    {
                        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy);
                    }
                    catch (Exception ex)
                    {
                        string desk = GetCurrentDesktopName();
                        throw new InvalidOperationException(
                            "Screen capture failed on desktop '" + desk + "' (desktop may be locked or running inside an isolated sandbox): " + ex.Message
                        );
                    }
                    finally
                    {
                        HudOverlay.ResumeAfterCapture();
                    }
                }

                double scale = 1.0;
                int outW = bounds.Width;
                int outH = bounds.Height;
                if (outW > maxWidth)
                {
                    scale = (double)maxWidth / outW;
                    outW = maxWidth;
                    outH = Math.Max(1, (int)Math.Round(bounds.Height * scale));
                }

                using (var outBmp = new Bitmap(outW, outH, PixelFormat.Format24bppRgb))
                {
                    using (Graphics g = Graphics.FromImage(outBmp))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawImage(rawBmp, 0, 0, outW, outH);

                        if (showGrid)
                        {
                            DrawNormalizedGrid(g, outW, outH);
                        }

                        if (showSoM && elements.Count > 0)
                        {
                            DrawSoMOverlays(g, elements, bounds, scale);
                        }

                        if (showCursor && bounds.Contains(cursorPt.X, cursorPt.Y))
                        {
                            float cx = (float)((cursorPt.X - bounds.Left) * scale);
                            float cy = (float)((cursorPt.Y - bounds.Top) * scale);
                            DrawCursorMarker(g, cx, cy);
                        }
                    }

                    byte[] bytes;
                    string mimeType = "image/png";
                    using (var ms = new MemoryStream())
                    {
                        outBmp.Save(ms, ImageFormat.Png);
                        bytes = ms.ToArray();
                    }

                    if (bytes.Length > 700 * 1024)
                    {
                        using (var msJpg = new MemoryStream())
                        {
                            ImageCodecInfo jpgCodec = GetJpegCodec();
                            if (jpgCodec != null)
                            {
                                var ep = new EncoderParameters(1);
                                ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 85L);
                                outBmp.Save(msJpg, jpgCodec, ep);
                                bytes = msJpg.ToArray();
                                mimeType = "image/jpeg";
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(outputPath))
                    {
                        string dir = Path.GetDirectoryName(outputPath);
                        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                        File.WriteAllBytes(outputPath, bytes);
                    }

                    Dictionary<string, object> fgInfo = GetForegroundInfo();
                    fgInfo["captureBounds"] = RectToDict(bounds);
                    fgInfo["imageSize"] = new Dictionary<string, object> { { "w", outW }, { "h", outH } };
                    fgInfo["scale"] = scale;
                    fgInfo["mimeType"] = mimeType;
                    fgInfo["base64"] = Convert.ToBase64String(bytes);
                    fgInfo["imagePath"] = outputPath;
                    fgInfo["elements"] = elements;
                    return fgInfo;
                }
            }
        }

        private static void DrawNormalizedGrid(Graphics g, int w, int h)
        {
            using (var pen = new Pen(Color.FromArgb(70, 0, 180, 255), 1f))
            using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var bgBrush = new SolidBrush(Color.FromArgb(140, 15, 23, 42)))
            using (var fgBrush = new SolidBrush(Color.White))
            {
                for (int n = 100; n < 1000; n += 100)
                {
                    float x = (float)(w * (n / 1000.0));
                    float y = (float)(h * (n / 1000.0));
                    g.DrawLine(pen, x, 0, x, h);
                    g.DrawLine(pen, 0, y, w, y);
                    string label = n.ToString();
                    g.FillRectangle(bgBrush, x + 2, 2, 24, 13);
                    g.DrawString(label, font, fgBrush, x + 2, 1);
                    g.FillRectangle(bgBrush, 2, y + 2, 24, 13);
                    g.DrawString(label, font, fgBrush, 2, y + 1);
                }
            }
        }

        private static void DrawSoMOverlays(Graphics g, List<Dictionary<string, object>> elements, Rectangle bounds, double scale)
        {
            Color[] palette = new Color[]
            {
                Color.FromArgb(220, 239, 68, 68),
                Color.FromArgb(220, 59, 130, 246),
                Color.FromArgb(220, 16, 185, 129),
                Color.FromArgb(220, 245, 158, 11),
                Color.FromArgb(220, 168, 85, 247)
            };

            using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var textBrush = new SolidBrush(Color.White))
            {
                foreach (var el in elements)
                {
                    int id = Convert.ToInt32(el["id"]);
                    var bbox = (Dictionary<string, object>)el["bbox"];
                    float x = (float)((Convert.ToInt32(bbox["x"]) - bounds.Left) * scale);
                    float y = (float)((Convert.ToInt32(bbox["y"]) - bounds.Top) * scale);
                    float w = (float)(Convert.ToInt32(bbox["w"]) * scale);
                    float h = (float)(Convert.ToInt32(bbox["h"]) * scale);
                    if (w < 4 || h < 4) continue;

                    Color c = palette[(id - 1) % palette.Length];
                    using (var pen = new Pen(c, 1.5f))
                    using (var tagBrush = new SolidBrush(c))
                    {
                        g.DrawRectangle(pen, x, y, w, h);
                        string tag = id.ToString();
                        SizeF sz = g.MeasureString(tag, font);
                        float tagY = Math.Max(0, y - sz.Height);
                        g.FillRectangle(tagBrush, x, tagY, sz.Width + 4, sz.Height);
                        g.DrawString(tag, font, textBrush, x + 2, tagY);
                    }
                }
            }
        }

        private static void DrawCursorMarker(Graphics g, float cx, float cy)
        {
            using (var outerPen = new Pen(Color.FromArgb(220, 255, 255, 255), 3f))
            using (var innerPen = new Pen(Color.FromArgb(240, 239, 68, 68), 1.5f))
            {
                g.DrawEllipse(outerPen, cx - 9, cy - 9, 18, 18);
                g.DrawEllipse(innerPen, cx - 9, cy - 9, 18, 18);
                g.DrawLine(innerPen, cx - 14, cy, cx + 14, cy);
                g.DrawLine(innerPen, cx, cy - 14, cx, cy + 14);
            }
        }

        private static ImageCodecInfo GetJpegCodec()
        {
            foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
            {
                if (codec.FormatID == ImageFormat.Jpeg.Guid) return codec;
            }
            return null;
        }

        private static Dictionary<string, object> ExecuteActions(Dictionary<string, object> payload)
        {
            bool failsafe = GetBool(payload, "failsafe", true);
            bool visualHud = GetBool(payload, "visualHud", true);
            bool cursorMorph = GetBool(payload, "cursorMorph", true);
            string coordSpace = GetString(payload, "coordSpace", "normalized_1000");
            string screenScope = GetString(payload, "screenScope", "active_monitor");
            string targetApp = GetString(payload, "targetApp", "").Trim();
            int imageWidth = GetInt(payload, "imageWidth", 0);
            int imageHeight = GetInt(payload, "imageHeight", 0);
            int preActionDelayMs = Math.Max(0, Math.Min(5000, GetInt(payload, "preActionDelayMs", 1500)));
            int postActionHoldMs = Math.Max(500, Math.Min(15000, GetInt(payload, "postActionHoldMs", 4000)));
            Color tealAccent = Color.FromArgb(20, 184, 166);
            Color tealBright = Color.FromArgb(45, 212, 191);
            int postActionDelayMs = Math.Max(0, GetInt(payload, "postActionDelayMs", 250));
            List<Dictionary<string, object>> actions = GetDictList(payload, "actions");

            if (!string.IsNullOrEmpty(targetApp))
            {
                Dictionary<string, object> curFg = GetForegroundInfo();
                string curProc = GetString(curFg, "processName", "");
                bool matched = string.Equals(curProc, targetApp, StringComparison.OrdinalIgnoreCase) ||
                               string.Equals(curProc.Replace(".exe", ""), targetApp.Replace(".exe", ""), StringComparison.OrdinalIgnoreCase);
                if (!matched)
                {
                    FocusWindow(new Dictionary<string, object>
                    {
                        { "processName", targetApp },
                        { "visualHud", false }
                    });
                }
            }

            Rectangle bounds = ResolveCaptureRect(screenScope);
            int executed = 0;
            bool interactiveDefault = string.Equals(GetCurrentDesktopName(), "Default", StringComparison.OrdinalIgnoreCase);
            bool useCursorMorph = cursorMorph && interactiveDefault;
            bool useHud = visualHud && interactiveDefault;
            bool hasMutating = false;
            Point previewTarget = Point.Empty;
            bool hasPreviewTarget = false;
            string firstVerb = "操作";

            foreach (var act in actions)
            {
                string t = GetString(act, "action", "").ToLowerInvariant();
                if (t != "screenshot" && t != "wait")
                {
                    if (!hasMutating)
                    {
                        hasMutating = true;
                        if (t == "move" || t == "click" || t == "double_click" || t == "triple_click" || t == "scroll")
                        {
                            if (act.ContainsKey("screenX") || (act.ContainsKey("x") && act.ContainsKey("y")))
                            {
                                previewTarget = ResolvePoint(act, bounds, coordSpace, imageWidth, imageHeight);
                                hasPreviewTarget = true;
                            }
                            firstVerb = (t == "move") ? "移动鼠标" : (t == "scroll" ? "滚动" : "点击目标");
                        }
                        else if (t == "drag")
                        {
                            firstVerb = "拖拽";
                        }
                        else if (t == "type" || t == "keypress")
                        {
                            firstVerb = "键盘输入";
                        }
                    }
                }
            }

            if (useCursorMorph && hasMutating)
            {
                CursorMorpher.Begin();
            }

            if (useHud && hasMutating && preActionDelayMs > 0)
            {
                int leadIn = HudOverlay.IsActive() ? Math.Min(preActionDelayMs, 600) : preActionDelayMs;
                var leadSw = Stopwatch.StartNew();
                while (leadSw.ElapsedMilliseconds < leadIn)
                {
                    if (failsafe)
                    {
                        NativeMethods.POINT pt;
                        NativeMethods.GetCursorPos(out pt);
                        Rectangle vs = SystemInformation.VirtualScreen;
                        if (pt.X <= vs.Left + 2 && pt.Y <= vs.Top + 2)
                        {
                            CursorMorpher.Restore();
                            HudOverlay.ShowState(bounds, Color.FromArgb(239, 68, 68), "Computer Use · 已触发急停取消", new Point(pt.X, pt.Y), true, 2200);
                            throw new InvalidOperationException("FAILSAFE_ABORT: Cancelled during pre-action countdown at (0, 0).");
                        }
                    }
                    int rem = Math.Max(0, leadIn - (int)leadSw.ElapsedMilliseconds);
                    NativeMethods.POINT curPt;
                    NativeMethods.GetCursorPos(out curPt);
                    HudOverlay.ShowCountdownSync(
                        bounds,
                        tealBright,
                        "准备" + firstVerb,
                        new Point(curPt.X, curPt.Y),
                        true,
                        previewTarget,
                        hasPreviewTarget,
                        leadIn,
                        rem
                    );
                    Thread.Sleep(85);
                }
            }

            try
            {
                foreach (var act in actions)
                {
                    string type = GetString(act, "action", "").ToLowerInvariant();
                    bool isMutatingAction = (type != "screenshot" && type != "wait");
                    if (failsafe && isMutatingAction)
                    {
                        NativeMethods.POINT pt;
                        NativeMethods.GetCursorPos(out pt);
                        Rectangle vs = SystemInformation.VirtualScreen;
                        if (pt.X <= vs.Left + 2 && pt.Y <= vs.Top + 2)
                        {
                            if (useHud)
                            {
                                HudOverlay.ShowState(bounds, Color.FromArgb(239, 68, 68), "AI 操控电脑 · 已急停中断", new Point(pt.X, pt.Y), true, 2200);
                            }
                            throw new InvalidOperationException("FAILSAFE_ABORT: Mouse cursor is at top-left failsafe corner.");
                        }
                    }
                    switch (type)
                    {
                        case "screenshot":
                            if (useHud)
                            {
                                HudOverlay.ShowState(bounds, tealAccent, "AI 开始操作 · 捕获当前屏幕", Point.Empty, false, 2400);
                            }
                            break;
                        case "wait":
                            int ms = Math.Max(20, Math.Min(10000, GetInt(act, "ms", 500)));
                            if (useHud)
                            {
                                HudOverlay.ShowState(bounds, tealAccent, "AI 开始操作 · 等待界面响应", Point.Empty, false, ms + 1200);
                            }
                            Thread.Sleep(ms);
                            break;
                        case "move":
                            Point movePt = ResolvePoint(act, bounds, coordSpace, imageWidth, imageHeight);
                            if (useHud)
                            {
                                HudOverlay.ShowState(bounds, tealBright, "AI 开始操作 · 移动鼠标", movePt, true, 2600);
                            }
                            SmoothMoveMouse(movePt.X, movePt.Y, bounds, useHud || useCursorMorph, useHud);
                            break;
                        case "click":
                        case "double_click":
                        case "triple_click":
                            Point clickPt = ResolvePoint(act, bounds, coordSpace, imageWidth, imageHeight);
                            string button = GetString(act, "button", "left").ToLowerInvariant();
                            List<string> clickMods = GetStringList(act, "keys");
                            int count = type == "triple_click" ? 3 : (type == "double_click" ? 2 : 1);
                            PerformClick(clickPt.X, clickPt.Y, button, count, clickMods, bounds, useHud, useHud || useCursorMorph);
                            break;
                        case "drag":
                            PerformDrag(act, bounds, coordSpace, imageWidth, imageHeight, useHud);
                            break;
                        case "scroll":
                            PerformScroll(act, bounds, coordSpace, imageWidth, imageHeight, useHud);
                            break;
                        case "type":
                            string text = GetString(act, "text", "");
                            int delay = Math.Max(0, Math.Min(100, GetInt(act, "delayMs", 0)));
                            if (useHud)
                            {
                                NativeMethods.POINT cur;
                                NativeMethods.GetCursorPos(out cur);
                                string preview = text.Replace("\r", " ").Replace("\n", " ");
                                if (preview.Length > 24) preview = preview.Substring(0, 24) + "...";
                                HudOverlay.ShowState(bounds, tealAccent, "AI 开始操作 · 输入 \"" + preview + "\"", new Point(cur.X, cur.Y), true, 3000);
                            }
                            TypeUnicodeText(text, delay);
                            break;
                        case "keypress":
                            List<string> keys = GetStringList(act, "keys");
                            if (keys.Count == 0)
                            {
                                string singleKey = GetString(act, "key", "");
                                if (!string.IsNullOrEmpty(singleKey)) keys.Add(singleKey);
                            }
                            if (useHud)
                            {
                                NativeMethods.POINT cur;
                                NativeMethods.GetCursorPos(out cur);
                                HudOverlay.ShowState(bounds, tealAccent, "AI 开始操作 · 快捷键 " + string.Join("+", keys.ToArray()), new Point(cur.X, cur.Y), true, 2800);
                            }
                            SendKeyChord(keys);
                            break;
                        default:
                            throw new InvalidOperationException("Unsupported computer action: " + type);
                    }
                    executed++;
                }
            }
            finally
            {
                if (useCursorMorph && hasMutating && !useHud)
                {
                    CursorMorpher.Restore();
                }
            }

            if (postActionDelayMs > 0)
            {
                Thread.Sleep(postActionDelayMs);
            }

            if (useHud)
            {
                NativeMethods.POINT endCur;
                NativeMethods.GetCursorPos(out endCur);
                HudOverlay.ShowCooldown(
                    bounds,
                    tealAccent,
                    "AI 已结束操作",
                    new Point(endCur.X, endCur.Y),
                    true,
                    postActionHoldMs
                );
            }

            Dictionary<string, object> capturePayload = new Dictionary<string, object>();
            capturePayload["screenScope"] = screenScope;
            capturePayload["maxImageWidth"] = GetInt(payload, "maxImageWidth", 1440);
            capturePayload["showSoM"] = GetBool(payload, "showSoM", false);
            capturePayload["showCursor"] = GetBool(payload, "showCursor", true);
            capturePayload["showGrid"] = GetBool(payload, "showGrid", false);
            capturePayload["outputPath"] = GetString(payload, "outputPath", "");
            capturePayload["visualHud"] = visualHud;
            capturePayload["cursorMorph"] = cursorMorph;
            capturePayload["postActionHoldMs"] = postActionHoldMs;
            capturePayload["_fromAct"] = true;

            Dictionary<string, object> snap = CaptureAndAnnotate(capturePayload);
            snap["executedActions"] = executed;
            return snap;
        }

        private static Point ResolvePoint(Dictionary<string, object> act, Rectangle bounds, string coordSpace, int imageW, int imageH)
        {
            if (act.ContainsKey("screenX") && act.ContainsKey("screenY"))
            {
                return new Point(GetInt(act, "screenX", 0), GetInt(act, "screenY", 0));
            }
            if (!act.ContainsKey("x") || !act.ContainsKey("y"))
            {
                NativeMethods.POINT cur;
                NativeMethods.GetCursorPos(out cur);
                return new Point(cur.X, cur.Y);
            }

            double rawX = GetDouble(act, "x", 0);
            double rawY = GetDouble(act, "y", 0);

            if (string.Equals(coordSpace, "screen_pixels", StringComparison.OrdinalIgnoreCase))
            {
                return new Point((int)Math.Round(rawX), (int)Math.Round(rawY));
            }
            if (string.Equals(coordSpace, "image_pixels", StringComparison.OrdinalIgnoreCase) && imageW > 0 && imageH > 0)
            {
                int px = bounds.Left + (int)Math.Round((rawX / imageW) * bounds.Width);
                int py = bounds.Top + (int)Math.Round((rawY / imageH) * bounds.Height);
                return new Point(px, py);
            }

            double nx = Math.Max(0.0, Math.Min(1000.0, rawX));
            double ny = Math.Max(0.0, Math.Min(1000.0, rawY));
            int sx = bounds.Left + (int)Math.Round((nx / 1000.0) * Math.Max(1, bounds.Width - 1));
            int sy = bounds.Top + (int)Math.Round((ny / 1000.0) * Math.Max(1, bounds.Height - 1));
            return new Point(sx, sy);
        }

        private static void MoveMouse(int screenX, int screenY)
        {
            Rectangle vs = SystemInformation.VirtualScreen;
            int dx = (int)Math.Round(((screenX - vs.Left) * 65535.0) / Math.Max(1, vs.Width - 1));
            int dy = (int)Math.Round(((screenY - vs.Top) * 65535.0) / Math.Max(1, vs.Height - 1));
            dx = Math.Max(0, Math.Min(65535, dx));
            dy = Math.Max(0, Math.Min(65535, dy));

            var inp = new NativeMethods.INPUT[1];
            inp[0].type = NativeMethods.INPUT_MOUSE;
            inp[0].U.mi.dx = dx;
            inp[0].U.mi.dy = dy;
            inp[0].U.mi.dwFlags = NativeMethods.MOUSEEVENTF_MOVE | NativeMethods.MOUSEEVENTF_ABSOLUTE | NativeMethods.MOUSEEVENTF_VIRTUALDESK;
            NativeMethods.SendInput(1, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
            NativeMethods.SetCursorPos(screenX, screenY);
        }

        private static void SmoothMoveMouse(int screenX, int screenY, Rectangle bounds, bool smooth, bool useHud)
        {
            if (!smooth)
            {
                MoveMouse(screenX, screenY);
                return;
            }
            NativeMethods.POINT start;
            NativeMethods.GetCursorPos(out start);
            double dist = Math.Sqrt(Math.Pow(screenX - start.X, 2) + Math.Pow(screenY - start.Y, 2));
            if (dist < 14)
            {
                MoveMouse(screenX, screenY);
                if (useHud)
                {
                    HudOverlay.ShowStateSync(bounds, Color.FromArgb(45, 212, 191), "AI 开始操作 · 移动鼠标", new Point(screenX, screenY), true, 3000);
                }
                return;
            }
            int steps = Math.Max(16, Math.Min(26, (int)Math.Round(dist / 35.0)));
            for (int i = 1; i <= steps; i++)
            {
                double t = (double)i / steps;
                double ease = 1.0 - Math.Pow(1.0 - t, 3);
                int ix = start.X + (int)Math.Round((screenX - start.X) * ease);
                int iy = start.Y + (int)Math.Round((screenY - start.Y) * ease);
                MoveMouse(ix, iy);
                if (useHud && (i % 2 == 0 || i == steps))
                {
                    HudOverlay.ShowStateSync(bounds, Color.FromArgb(45, 212, 191), "AI 开始操作 · 移动鼠标", new Point(ix, iy), true, 3000);
                }
                Thread.Sleep(15);
            }
        }

        private static void PerformClick(int x, int y, string button, int count, List<string> modifiers, Rectangle bounds, bool useHud, bool smooth)
        {
            SmoothMoveMouse(x, y, bounds, smooth, useHud);
            if (useHud)
            {
                Color rippleCol = Color.FromArgb(45, 212, 191);
                string verb = count == 3 ? "三击" : (count == 2 ? "双击" : (button == "right" ? "右键点击" : "点击目标"));
                HudOverlay.TriggerRipple(bounds, x, y, rippleCol, "AI 开始操作 · " + verb, 3200);
                Thread.Sleep(85);
            }
            else
            {
                Thread.Sleep(35);
            }

            var modVks = new List<ushort>();
            foreach (string m in modifiers)
            {
                ushort vk;
                if (KeyMapper.TryGetVirtualKey(m, out vk)) modVks.Add(vk);
            }

            foreach (ushort vk in modVks) SendKeyEvent(vk, false);

            uint downFlag = NativeMethods.MOUSEEVENTF_LEFTDOWN;
            uint upFlag = NativeMethods.MOUSEEVENTF_LEFTUP;
            if (button == "right") { downFlag = NativeMethods.MOUSEEVENTF_RIGHTDOWN; upFlag = NativeMethods.MOUSEEVENTF_RIGHTUP; }
            else if (button == "middle") { downFlag = NativeMethods.MOUSEEVENTF_MIDDLEDOWN; upFlag = NativeMethods.MOUSEEVENTF_MIDDLEUP; }

            for (int i = 0; i < count; i++)
            {
                var inp = new NativeMethods.INPUT[2];
                inp[0].type = NativeMethods.INPUT_MOUSE;
                inp[0].U.mi.dwFlags = downFlag;
                inp[1].type = NativeMethods.INPUT_MOUSE;
                inp[1].U.mi.dwFlags = upFlag;
                NativeMethods.SendInput(2, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
                if (i + 1 < count) Thread.Sleep(45);
            }

            for (int i = modVks.Count - 1; i >= 0; i--) SendKeyEvent(modVks[i], true);
        }

        private static void PerformDrag(Dictionary<string, object> act, Rectangle bounds, string coordSpace, int imageW, int imageH, bool useHud)
        {
            List<Dictionary<string, object>> pathPts = GetDictList(act, "path");
            Point startPt;
            Point endPt;

            if (pathPts.Count >= 2)
            {
                startPt = ResolvePoint(pathPts[0], bounds, coordSpace, imageW, imageH);
                endPt = ResolvePoint(pathPts[pathPts.Count - 1], bounds, coordSpace, imageW, imageH);
            }
            else
            {
                var p1 = new Dictionary<string, object> { { "x", GetDouble(act, "fromX", 0) }, { "y", GetDouble(act, "fromY", 0) } };
                var p2 = new Dictionary<string, object> { { "x", GetDouble(act, "toX", 0) }, { "y", GetDouble(act, "toY", 0) } };
                startPt = ResolvePoint(p1, bounds, coordSpace, imageW, imageH);
                endPt = ResolvePoint(p2, bounds, coordSpace, imageW, imageH);
            }

            SmoothMoveMouse(startPt.X, startPt.Y, bounds, true, useHud);
            if (useHud)
            {
                HudOverlay.SetDragLine(startPt, endPt, true);
                HudOverlay.ShowState(bounds, Color.FromArgb(20, 184, 166), "AI 开始操作 · 拖拽中", startPt, true, 3000);
            }
            Thread.Sleep(30);
            var down = new NativeMethods.INPUT[1];
            down[0].type = NativeMethods.INPUT_MOUSE;
            down[0].U.mi.dwFlags = NativeMethods.MOUSEEVENTF_LEFTDOWN;
            NativeMethods.SendInput(1, down, Marshal.SizeOf(typeof(NativeMethods.INPUT)));

            int steps = 12;
            for (int i = 1; i <= steps; i++)
            {
                int ix = startPt.X + (int)Math.Round(((endPt.X - startPt.X) * (double)i) / steps);
                int iy = startPt.Y + (int)Math.Round(((endPt.Y - startPt.Y) * (double)i) / steps);
                MoveMouse(ix, iy);
                if (useHud && (i % 3 == 0 || i == steps))
                {
                    HudOverlay.ShowState(bounds, Color.FromArgb(20, 184, 166), "AI 开始操作 · 拖拽中", new Point(ix, iy), true, 3000);
                }
                Thread.Sleep(15);
            }

            var up = new NativeMethods.INPUT[1];
            up[0].type = NativeMethods.INPUT_MOUSE;
            up[0].U.mi.dwFlags = NativeMethods.MOUSEEVENTF_LEFTUP;
            NativeMethods.SendInput(1, up, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
            if (useHud)
            {
                HudOverlay.SetDragLine(Point.Empty, Point.Empty, false);
                HudOverlay.TriggerRipple(bounds, endPt.X, endPt.Y, Color.FromArgb(45, 212, 191), "AI 开始操作 · 完成拖拽", 2800);
            }
        }

        private static void PerformScroll(Dictionary<string, object> act, Rectangle bounds, string coordSpace, int imageW, int imageH, bool useHud)
        {
            Point scrollPt;
            if (act.ContainsKey("x") && act.ContainsKey("y"))
            {
                scrollPt = ResolvePoint(act, bounds, coordSpace, imageW, imageH);
                SmoothMoveMouse(scrollPt.X, scrollPt.Y, bounds, true, useHud);
                Thread.Sleep(20);
            }
            else
            {
                NativeMethods.POINT cur;
                NativeMethods.GetCursorPos(out cur);
                scrollPt = new Point(cur.X, cur.Y);
            }

            if (useHud)
            {
                HudOverlay.TriggerRipple(bounds, scrollPt.X, scrollPt.Y, Color.FromArgb(45, 212, 191), "AI 开始操作 · 滚动页面", 2600);
            }

            int scrollY = GetInt(act, "scrollY", 0);
            int scrollX = GetInt(act, "scrollX", 0);

            if (scrollY != 0)
            {
                // Positive scrollY scrolls down -> negative Win32 WHEEL_DELTA
                int delta = Math.Abs(scrollY) <= 20 ? -scrollY * 120 : -scrollY;
                var inp = new NativeMethods.INPUT[1];
                inp[0].type = NativeMethods.INPUT_MOUSE;
                inp[0].U.mi.dwFlags = NativeMethods.MOUSEEVENTF_WHEEL;
                inp[0].U.mi.mouseData = delta;
                NativeMethods.SendInput(1, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
            }
            if (scrollX != 0)
            {
                int delta = Math.Abs(scrollX) <= 20 ? scrollX * 120 : scrollX;
                var inp = new NativeMethods.INPUT[1];
                inp[0].type = NativeMethods.INPUT_MOUSE;
                inp[0].U.mi.dwFlags = NativeMethods.MOUSEEVENTF_HWHEEL;
                inp[0].U.mi.mouseData = delta;
                NativeMethods.SendInput(1, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
            }
        }

        private static void TypeUnicodeText(string text, int delayMs)
        {
            if (string.IsNullOrEmpty(text)) return;
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (ch == '\r')
                {
                    if (i + 1 < text.Length && text[i + 1] == '\n') i++;
                    SendKeyChord(new List<string> { "Return" });
                    continue;
                }
                if (ch == '\n')
                {
                    SendKeyChord(new List<string> { "Return" });
                    continue;
                }
                if (ch == '\t')
                {
                    SendKeyChord(new List<string> { "Tab" });
                    continue;
                }

                var inp = new NativeMethods.INPUT[2];
                inp[0].type = NativeMethods.INPUT_KEYBOARD;
                inp[0].U.ki.wScan = ch;
                inp[0].U.ki.dwFlags = NativeMethods.KEYEVENTF_UNICODE;
                inp[1].type = NativeMethods.INPUT_KEYBOARD;
                inp[1].U.ki.wScan = ch;
                inp[1].U.ki.dwFlags = NativeMethods.KEYEVENTF_UNICODE | NativeMethods.KEYEVENTF_KEYUP;
                NativeMethods.SendInput(2, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));

                if (delayMs > 0) Thread.Sleep(delayMs);
            }
        }

        private static void SendKeyChord(List<string> keys)
        {
            if (keys == null || keys.Count == 0) return;
            var vks = new List<ushort>();
            foreach (string raw in keys)
            {
                string[] parts = raw.Split(new char[] { '+' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string part in parts)
                {
                    ushort vk;
                    if (!KeyMapper.TryGetVirtualKey(part, out vk))
                    {
                        throw new ArgumentException("Unknown key name: " + part);
                    }
                    vks.Add(vk);
                }
            }
            if (vks.Count == 0) return;

            for (int i = 0; i < vks.Count; i++)
            {
                SendKeyEvent(vks[i], false);
                Thread.Sleep(10);
            }
            for (int i = vks.Count - 1; i >= 0; i--)
            {
                SendKeyEvent(vks[i], true);
                Thread.Sleep(10);
            }
        }

        private static void SendKeyEvent(ushort vk, bool keyUp)
        {
            uint flags = keyUp ? NativeMethods.KEYEVENTF_KEYUP : 0;
            if (KeyMapper.IsExtendedKey(vk)) flags |= NativeMethods.KEYEVENTF_EXTENDEDKEY;
            ushort scan = (ushort)NativeMethods.MapVirtualKey(vk, 0);

            var inp = new NativeMethods.INPUT[1];
            inp[0].type = NativeMethods.INPUT_KEYBOARD;
            inp[0].U.ki.wVk = vk;
            inp[0].U.ki.wScan = scan;
            inp[0].U.ki.dwFlags = flags;
            NativeMethods.SendInput(1, inp, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
        }

        private static Dictionary<string, object> RectToDict(Rectangle r)
        {
            return new Dictionary<string, object>
            {
                { "x", r.Left },
                { "y", r.Top },
                { "w", r.Width },
                { "h", r.Height }
            };
        }

        private static Dictionary<string, object> ParseDict(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return new Dictionary<string, object>();
            object obj = Json.DeserializeObject(raw);
            var d = obj as Dictionary<string, object>;
            return d ?? new Dictionary<string, object>();
        }

        private static Dictionary<string, object> GetDict(Dictionary<string, object> d, string key)
        {
            object val;
            if (d != null && d.TryGetValue(key, out val))
            {
                var sub = val as Dictionary<string, object>;
                if (sub != null) return sub;
            }
            return new Dictionary<string, object>();
        }

        private static string GetString(Dictionary<string, object> d, string key, string fallback)
        {
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null) return val.ToString();
            return fallback;
        }

        private static int GetInt(Dictionary<string, object> d, string key, int fallback)
        {
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null)
            {
                try { return Convert.ToInt32(val); } catch { }
            }
            return fallback;
        }

        private static double GetDouble(Dictionary<string, object> d, string key, double fallback)
        {
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null)
            {
                try { return Convert.ToDouble(val); } catch { }
            }
            return fallback;
        }

        private static bool GetBool(Dictionary<string, object> d, string key, bool fallback)
        {
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null)
            {
                try { return Convert.ToBoolean(val); } catch { }
            }
            return fallback;
        }

        private static List<Dictionary<string, object>> GetDictList(Dictionary<string, object> d, string key)
        {
            var result = new List<Dictionary<string, object>>();
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null)
            {
                var arr = val as object[];
                if (arr != null)
                {
                    foreach (object o in arr)
                    {
                        var item = o as Dictionary<string, object>;
                        if (item != null) result.Add(item);
                    }
                    return result;
                }
                var list = val as System.Collections.IList;
                if (list != null)
                {
                    foreach (object o in list)
                    {
                        var item = o as Dictionary<string, object>;
                        if (item != null) result.Add(item);
                    }
                }
            }
            return result;
        }

        private static List<string> GetStringList(Dictionary<string, object> d, string key)
        {
            var result = new List<string>();
            object val;
            if (d != null && d.TryGetValue(key, out val) && val != null)
            {
                var list = val as System.Collections.IEnumerable;
                if (list != null && !(val is string))
                {
                    foreach (object o in list)
                    {
                        if (o != null) result.Add(o.ToString());
                    }
                }
            }
            return result;
        }
    }
}
